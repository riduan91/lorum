# ESG Data Migration Guide

## Overview
This document explains the migration from the SQL stored procedure `stpDMIRESGData.sql` to the Python ESG data processing modules integrated within the `workflow_bench_instr_indicators.py`.

## SQL Source
- **File**: `dags/sql/stpDMIRESGData.sql`
- **Total Lines**: 1162
- **Purpose**: Processes ESG (Environmental, Social, Governance) data, CO2 intensity, controversy scores, and sustainability metrics

## Python Implementation

### Primary Module
- **File**: `dags/sustainability_scores/esg_data.py`
- **Purpose**: Core ESG data processing functions

### Integration File
- **File**: `dags/benchmark_aggregates_holdings/workflow_bench_instr_indicators.py`
- **Purpose**: Airflow task orchestration for ESG data integration

## Functional Mapping

### 1. ESG Scope Definition
**SQL Section**: Lines 50-100 (scope creation)
**Python Implementation**: `compute_scope_for_esg_calculation()`

**SQL Logic**:
```sql
select strPortfGPSCode as myKey,
    res.datPeriodLastDay as datReportingDay,
    res.numInstID,
    i.strInstAladdin,
    i.strInstIssuerCode,
    res.numInstrWeight as numInstrWeight
into #esgscope
from tblDMIRDMCPortfInstrIndicatorsWrk res
inner join DMIR.tblDMIRBRSInstrument i on i.strInstAladdin = res.strInstAladdin
```

**Python Equivalent**:
```python
def compute_scope_for_esg_calculation(**kwargs):
    """
    Compute scope for ESG calculation.
    Equivalent to SQL ESG scope definition.
    """
    # Load instrument data from previous workflow stages
    # Filter for valid instrument types
    # Prepare ESG calculation scope
```

### 2. Core ESG Data Processing

#### A. ESG Scores
**SQL Section**: Lines 200-400 (ESG score extraction)
**Python Implementation**: `process_esg()`

**SQL Logic**: Complex joins with ESG data tables and issuer mappings
```sql
SELECT 
    e.numInstID,
    e.strInstIssuerCode,
    e.numESGGlbScore,
    e.numESGEnvScore,
    e.numESGSocScore,
    e.numESGGovScore
FROM DWGN.tblDWGNSustainabilityScores_Issr_ESG e
```

**Python Equivalent**:
```python
def process_esg(df_scope):
    """
    Process ESG scores for instruments.
    Equivalent to SQL lines 200-400 in stpDMIRESGData.sql
    """
    session = get_session()
    try:
        # Query ESG data from DWGN tables
        # Apply instrument and issuer mappings
        # Calculate weighted ESG scores
        # Return processed ESG data
```

#### B. CO2 Intensity Data
**SQL Section**: Lines 400-600 (CO2 data processing)
**Python Implementation**: `process_co2()`

**SQL Logic**: CO2 intensity calculations with green bond considerations
```sql
SELECT 
    co2.numInstID,
    co2.strInstIssuerCode,
    co2.numCO2IntensEVEval,
    co2.numCO2IntensScope1,
    co2.numCO2IntensScope2
FROM DWGN.tblDWGNSustainabilityScores_Issr_C02 co2
```

**Python Equivalent**:
```python
def process_co2(df_scope):
    """
    Process CO2 intensity data.
    Equivalent to SQL lines 400-600 in stpDMIRESGData.sql
    """
    # Extract CO2 intensity metrics
    # Handle green bond adjustments
    # Calculate coverage statistics
```

#### C. Controversy Scores
**SQL Section**: Lines 600-750 (controversy data)
**Python Implementation**: `process_controverse()`

**SQL Logic**: Controversy score extraction and weighting
```sql
SELECT 
    c.strInstIssuerCode,
    c.numControverseScore,
    c.datControverseDate
FROM DWGN.tblDWGNControverse c
WHERE c.datControverseDate = (
    SELECT MAX(datControverseDate) 
    FROM DWGN.tblDWGNControverse c2 
    WHERE c2.strInstIssuerCode = c.strInstIssuerCode
)
```

**Python Equivalent**:
```python
def process_controverse(df_scope):
    """
    Process controversy scores.
    Equivalent to SQL lines 600-750 in stpDMIRESGData.sql
    """
    # Get latest controversy scores by issuer
    # Apply controversy weighting logic
    # Handle missing controversy data
```

#### D. Engagement Data
**SQL Section**: Lines 750-900 (engagement metrics)
**Python Implementation**: `process_engagement()`

**SQL Logic**: Engagement score calculation based on calendar year
```sql
SELECT 
    eng.strInstIssuerCode,
    eng.numEngagementScore,
    eng.strEngagementType
FROM DWGN.tblDWGNEngagement eng
WHERE YEAR(eng.datEngagementDate) = YEAR(GETDATE()) - 1
```

**Python Equivalent**:
```python
def process_engagement(df_scope):
    """
    Process engagement data.
    Equivalent to SQL lines 750-900 in stpDMIRESGData.sql
    """
    # Filter engagement data by calendar year
    # Calculate engagement scores
    # Apply engagement type classifications
```

#### E. Diversity Metrics
**SQL Section**: Lines 900-1000 (diversity data)
**Python Implementation**: `process_diversity()`

**SQL Logic**: Diversity score extraction and processing
```sql
SELECT 
    d.strInstIssuerCode,
    d.numDiversityScore,
    d.strDiversityCategory
FROM DWGN.tblDWGNDiversity d
```

**Python Equivalent**:
```python
def process_diversity(df_scope):
    """
    Process diversity metrics.
    Equivalent to SQL lines 900-1000 in stpDMIRESGData.sql
    """
    # Extract diversity scores by issuer
    # Apply diversity categorizations
    # Calculate diversity coverage
```

#### F. Human Rights Data
**SQL Section**: Lines 1000-1100 (human rights metrics)
**Python Implementation**: `process_humanrights()`

**SQL Logic**: Human rights score processing
```sql
SELECT 
    hr.strInstIssuerCode,
    hr.numHumanRightsScore,
    hr.datHumanRightsAssessment
FROM DWGN.tblDWGNHumanRights hr
```

**Python Equivalent**:
```python
def process_humanrights(df_scope):
    """
    Process human rights data.
    Equivalent to SQL lines 1000-1100 in stpDMIRESGData.sql
    """
    # Extract human rights scores
    # Apply assessment date filters
    # Calculate human rights coverage
```

#### G. Group Data Processing
**SQL Section**: Lines 1100-1162 (group consolidation)
**Python Implementation**: `process_group()`

**SQL Logic**: Group-level ESG data consolidation
**Python Equivalent**:
```python
def process_group(df_scope):
    """
    Process group-level ESG data.
    Equivalent to SQL group consolidation logic.
    """
    # Consolidate ESG data at group level
    # Handle parent-subsidiary relationships
    # Apply group weighting rules
```

### 3. Data Integration and Combination

#### A. Coverage Calculations
**SQL Section**: Throughout procedure (coverage logic)
**Python Implementation**: `compute_potential_coverage()`

**SQL Logic**: Complex coverage calculations with multiple conditions
```sql
-- Coverage calculation example
numESGGlbScoreCov = 
    CASE WHEN e.numESGGlbScore IS NOT NULL 
         AND e.strESGGlbScoreStat != 'N'
         THEN scope.numInstrWeight 
         ELSE 0 
    END
```

**Python Equivalent**:
```python
def compute_potential_coverage(df_all_combined, df_scope):
    """
    Compute potential ESG coverage metrics.
    Equivalent to SQL coverage calculation logic.
    """
    # Calculate coverage for each ESG component
    # Apply validity checks (stat != 'N')
    # Weight coverage by instrument weight
```

#### B. Data Consolidation
**SQL Section**: Final SELECT statements (data output)
**Python Implementation**: `combine_all()`

**SQL Logic**: Final data combination and output preparation
**Python Equivalent**:
```python
def combine_all(df_scope, df_esg, df_co2, df_controverse, 
                df_engagement, df_diversity, df_humanrights, df_group):
    """
    Combine all ESG data components.
    Equivalent to SQL final data consolidation.
    """
    # Merge all ESG components
    # Apply business logic for missing data
    # Prepare final ESG dataset
```

### 4. Workflow Integration

The Python implementation integrates ESG processing into the main workflow:

```python
@task_group
def esg_processing_group():
    """ESG data processing task group."""
    
    esg_scope = task__compute_scope_for_esg_calculation()
    
    # Parallel ESG data processing
    esg_data = task__compute_esg_data(esg_scope)
    co2_data = task__compute_co2_data(esg_scope)
    controverse_data = task__compute_controverse_data(esg_scope)
    engagement_data = task__compute_engagement_data(esg_scope)
    diversity_data = task__compute_diversity_data(esg_scope)
    humanrights_data = task__compute_humanrights_data(esg_scope)
    group_data = task__compute_group_data(esg_scope)
    
    # Combine all ESG data
    combined_esg = task__combine_all_esg(
        esg_scope, esg_data, co2_data, controverse_data,
        engagement_data, diversity_data, humanrights_data, group_data
    )
    
    return combined_esg
```

## Key Data Transformations

### 1. ESG Score Weighting
**SQL**: Complex weighted calculations
```sql
numESGGlbScoreWeighted = 
    SUM(CASE WHEN e.numESGGlbScore IS NOT NULL 
        THEN scope.numInstrWeight * e.numESGGlbScore 
        ELSE 0 END) / 
    SUM(CASE WHEN e.numESGGlbScore IS NOT NULL 
        THEN scope.numInstrWeight 
        ELSE 0 END)
```

**Python**:
```python
# Calculate weighted ESG scores
valid_esg = df['numESGGlbScore'].notna()
df['weighted_score'] = np.where(valid_esg, 
                                df['numInstrWeight'] * df['numESGGlbScore'], 
                                0)
df['weighted_sum'] = np.where(valid_esg, df['numInstrWeight'], 0)

weighted_avg = df['weighted_score'].sum() / df['weighted_sum'].sum()
```

### 2. Coverage Calculations
**SQL**: Coverage based on data availability and validity
```sql
numCoveragePct = 
    SUM(CASE WHEN e.numESGGlbScore IS NOT NULL 
             AND e.strESGGlbScoreStat != 'N'
        THEN scope.numInstrWeight 
        ELSE 0 END) * 100.0 / SUM(scope.numInstrWeight)
```

**Python**:
```python
def calculate_coverage(df, score_col, stat_col):
    valid_data = (df[score_col].notna()) & (df[stat_col] != 'N')
    coverage_weight = df.loc[valid_data, 'numInstrWeight'].sum()
    total_weight = df['numInstrWeight'].sum()
    return (coverage_weight / total_weight) * 100 if total_weight > 0 else 0
```

### 3. Green Bond Adjustments
**SQL**: Special handling for green bonds in CO2 calculations
```sql
-- Green bonds get special CO2 treatment
numCO2IntensEVEval = 
    CASE WHEN thematic.strThematicType = 'Green Bonds'
         THEN 0  -- Green bonds get zero CO2 intensity
         ELSE co2.numCO2IntensEVEval
    END
```

**Python**:
```python
# Apply green bond CO2 adjustments
df['numCO2IntensEVEval'] = np.where(
    df['strThematicType'] == 'Green Bonds',
    0,  # Green bonds get zero CO2 intensity
    df['numCO2IntensEVEval']
)
```

## Performance Optimizations

### 1. Parallel Processing
- **SQL**: Single procedure with sequential processing
- **Python**: Parallel task execution for different ESG components

### 2. Data Chunking
- **SQL**: Processes all data in single queries
- **Python**: Chunks large datasets for memory efficiency

### 3. Caching Strategy
- **SQL**: No explicit caching
- **Python**: Intermediate results cached between workflow tasks

### 4. Memory Management
- **SQL**: Database manages memory automatically
- **Python**: Explicit memory cleanup and garbage collection

## Data Quality Checks

### 1. Data Validation
The Python implementation includes comprehensive validation:

```python
def validate_esg_data(df):
    """Validate ESG data quality."""
    checks = {
        'missing_scores': df['numESGGlbScore'].isna().sum(),
        'invalid_status': (df['strESGGlbScoreStat'] == 'N').sum(),
        'coverage_rate': calculate_coverage(df, 'numESGGlbScore', 'strESGGlbScoreStat')
    }
    return checks
```

### 2. Coverage Monitoring
Monitor ESG data coverage across different dimensions:
- By instrument type
- By issuer region
- By market capitalization
- By sector classification

## Testing and Validation

### Data Consistency Checks
Compare Python output with SQL output for:
1. ESG score calculations and weightings
2. CO2 intensity adjustments for green bonds
3. Controversy score assignments
4. Coverage percentage calculations
5. Engagement and diversity metrics

### Performance Validation
- Processing time for large ESG datasets
- Memory usage during ESG data merging
- Parallel task execution efficiency
- Database query performance

## Maintenance Notes

### Common Issues
1. **ESG Data Latency**: Handle delays in external ESG data feeds
2. **Coverage Fluctuations**: Monitor and explain coverage changes
3. **Data Quality**: Handle invalid or missing ESG scores gracefully

### ESG Data Source Management
- ESG data comes from multiple external providers
- Data refresh schedules may vary by provider
- Implement robust error handling for ESG API failures

### Future Enhancements
When adding new ESG metrics:
1. Follow the existing process_* function pattern
2. Add appropriate data validation
3. Update coverage calculations
4. Include in the combine_all function

## Dependencies
- pandas and numpy for data processing
- SQLAlchemy for database operations  
- Custom ESG data models
- Workflow orchestration via Airflow
- External ESG data provider APIs
