# Benchmark Data BRS Migration Guide

## Overview
This document explains the migration from the SQL stored procedure `stpDMIRBenchData_BRS` to the Python workflow/procedure pair: `workflow_benchmark_data.py` and `procedure_benchmark_data.py`.

## SQL Source
- **Stored Procedure**: `stpDMIRBenchData_BRS`
- **SQL File**: `dags/sql/stpDMIRBenchData_BRS.sql`
- **Total Lines**: 520
- **Purpose**: Processes BRS benchmark data constituents with market cap calculations, currency conversions, and data lifecycle management

## Python Implementation

### Workflow File
- **File**: `dags/benchmark_data_brs/workflow_benchmark_data.py`
- **Purpose**: Airflow task orchestration for benchmark data processing

### Procedure File
- **File**: `dags/benchmark_data_brs/procedure_benchmark_data.py`
- **Purpose**: Core business logic for benchmark constituent data processing

---

## 1. Tables Used as Inputs

| Table Name                              | Description                                                                                                          |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **DWGN.tblDWGNBenchmarkConstituents**  | Source BRS benchmark constituents: per-benchmark, per-date positions with market caps, quantities, and currency data |
| **DMIR.tblDMIRBRSInstrument**          | Instrument master: maps internal codes and ISINs to `numInstID`                                                     |
| **DMIR.tblDMIRBRSCurrencyQuote**       | Currency exchange rates: daily rates for converting local currencies to EUR                                          |
| **DWGN.tblDWGNFimParam**               | Parameter table: stores last run audit ID for incremental processing                                                |

---

## 2. Target Tables

- **DMIR.tblDMIRBRSBenchmarkConstituent**  
  *In Python:* populated via `insert_final_records()` function with processed benchmark constituent data.  
  *Description:* Final repository for benchmark constituent positions with EUR market caps, instrument mappings, and audit trails.

- **DWGN.tblDWGNFimParam**  
  *In Python:* updated in `update_audit_id()` via SQLAlchemy `UPDATE` calls.  
  *Description:* receives the latest `numAuditId` for tracking processing runs and enabling incremental updates.

---

## 3. Temporary (Staging) Tables / DataFrames

| Staging Table (SQL)                    | Purpose / Description                                                                                                | Equivalent pandas DataFrame(s)                      |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| **#BenchmarksScope**                   | Distinct benchmark/date combinations requiring processing (last 30 days)                                            | `df_benchmarks_scope` in `data_benchmarks_scope()`  |
| **#constituent**                       | Raw constituent data with market caps, quantities, currencies before instrument mapping                             | `df_constituents` in `data_constituents()`          |
| **#updated_constituent**               | Constituents with instrument IDs mapped via internal codes and ISIN fallbacks                                       | `df_updated_constituents` in `update_data_constituents()` |
| **#final_constituent**                 | Final constituent records with EUR market caps calculated via currency conversion                                     | `df_final_records` in `calculate_market_cap_eur()`   |
| *currency staging*                     | Currency quotes merged for market cap conversion calculations                                                        | `df_currency_merged` in processing functions         |
| *validation staging*                   | Data quality checks for missing instruments, invalid market caps, currency coverage                                  | `validation_results` dictionaries throughout pipeline |

---

## 4. Task Breakdown for the Airflow DAG

| Task Name (`@task`)                              | Description                                                                                                                                                                                                                      | Inputs / Outputs                                                    | Parallelizable?                                    |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- | -------------------------------------------------- |
| **task__clean_data_folder**                     | Initialize processing environment: clean temporary files, prepare directories, set up logging infrastructure                                                                                                                     | **In:** none  <br>**Out:** clean environment status                | ❌ (must run first to prepare environment)         |
| **task__get_old_audit_id**                      | Retrieve last processed audit ID from parameter table, calculate date offsets for conflict avoidance                                                                                                                          | **In:** none (DB connection) <br>**Out:** `old_audit_id`           | ❌ (required for incremental processing setup)     |
| **task__data_benchmarks_scope**                 | Identify benchmarks requiring updates: query distinct benchmark/date combinations from last 30 days                                                                                                                            | **In:** `old_audit_id` <br>**Out:** `df_benchmarks_scope`          | ❌ (defines scope for all downstream processing)   |
| **task__data_constituents**                     | Extract raw constituent data for benchmarks in scope: market caps, quantities, currencies, internal codes                                                                                                                      | **In:** `df_benchmarks_scope` <br>**Out:** `df_constituents`       | ✔️ (can chunk benchmark queries in parallel)      |
| **task__get_data_instruments**                  | Load instrument master data: retrieve instrument mappings for internal codes found in constituents                                                                                                                              | **In:** constituent codes list <br>**Out:** `df_instruments`       | ✔️ (chunk and parallelize instrument queries)     |
| **task__update_data_constituents**              | Map instrument IDs to constituents: primary mapping by Aladdin codes, fallback by ISIN codes                                                                                                                                   | **In:** `df_constituents`, `df_instruments` <br>**Out:** `df_updated_constituents` | ✔️ (mapping operations can be parallelized)       |
| **task__calculate_market_cap_eur**              | Currency conversion and market cap calculation: merge with currency quotes, apply EUR conversion rates                                                                                                                          | **In:** `df_updated_constituents` <br>**Out:** `df_final_records`  | ✔️ (currency lookups can be parallel)             |
| **task__delete_records_thirty_six_month**       | Data lifecycle cleanup: remove records older than 36 months across all benchmarks                                                                                                                                              | **In:** current date <br>**Out:** deletion count                   | ✔️ (independent cleanup, can run in parallel)     |
| **task__delete_records_six_month**              | Targeted cleanup: remove records older than 6 months for benchmarks in current scope                                                                                                                                           | **In:** `df_benchmarks_scope` <br>**Out:** deletion count          | ✔️ (can batch delete operations)                   |
| **task__delete_existing_combinations**          | Remove existing records that will be replaced: delete current benchmark/date combinations before inserting fresh data                                                                                                          | **In:** `df_final_records` <br>**Out:** deletion count             | ✔️ (batch deletions by benchmark groups)          |
| **task__insert_final_records**                  | Bulk insert processed records: insert final constituent data with audit trails and EUR market caps                                                                                                                             | **In:** `df_final_records`, `audit_id` <br>**Out:** insertion count | ❌ (final insertion must be sequential for consistency) |
| **task__update_audit_id**                       | Update processing checkpoint: record latest audit ID in parameter table for next incremental run                                                                                                                               | **In:** `audit_id` <br>**Out:** update status                      | ❌ (final checkpoint update)                       |

> **Concurrency Notes**  
> - **Benchmark queries** in `data_constituents` can chunk by benchmark groups and run in parallel  
> - **Instrument lookups** can use thread pools to parallelize database queries for different instrument batches  
> - **Currency conversion** operations can process different currency groups in parallel  
> - **Deletion operations** can be batched and parallelized by benchmark or date ranges  
> - **Data validation** checks can run in parallel with main processing pipeline

---

## 5. High‑Level DAG Structure Diagram

```text
      ┌─────────────────────────────────┐
      │ task__clean_data_folder         │
      └─────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────┐
      │ task__get_old_audit_id          │
      └─────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────┐
      │ task__data_benchmarks_scope     │
      └─────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────┐
      │ task__data_constituents         │
      └─────────────────────────────────┘
                    ↙         ↘
      ┌──────────────────┐    ┌──────────────────────────────┐
      │ task__get_data_  │    │ task__delete_records_        │
      │ instruments      │    │ thirty_six_month             │
      └──────────────────┘    └──────────────────────────────┘
                    ↓                          ↓
      ┌─────────────────────────────────┐      │
      │ task__update_data_constituents  │      │
      └─────────────────────────────────┘      │
                         ↓                     │
      ┌─────────────────────────────────┐      │
      │ task__calculate_market_cap_eur  │      │
      └─────────────────────────────────┘      │
                    ↙         ↘               │
      ┌──────────────────┐    ┌──────────────────────────────┐
      │ task__delete_    │    │ task__delete_existing_       │
      │ records_six_     │    │ combinations                 │
      │ month            │    └──────────────────────────────┘
      └──────────────────┘                   ↓
                    ↓                        │
                    └──────────────┬─────────┘
                                   ↓
      ┌─────────────────────────────────┐
      │ task__insert_final_records      │
      └─────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────┐
      │ task__update_audit_id           │
      └─────────────────────────────────┘
```
