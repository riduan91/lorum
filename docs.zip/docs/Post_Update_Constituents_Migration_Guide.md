# Post Update Constituents Migration Guide

## Overview
This document explains the migration from the SQL stored procedure `stpDMIRBenchmarkAggregate` (part 1) to the Python workflow/procedure pair: `workflow_post_update_constituents.py` and `procedure_post_update_constituents.py`.

## SQL Source
- **Stored Procedure**: `stpDMIRBenchmarkAggregate` (part 1)
- **SQL File**: `dags/sql/stpDMIRBenchmarkAggregate.sql`
- **Lines Covered**: 1-140 (constituent update and link table management)
- **Purpose**: Post-processing of benchmark constituents to fix missing instrument mappings and maintain FBA-to-BKGN linkages

## Python Implementation

### Workflow File
- **File**: `dags/benchmark_aggregates_holdings/workflow_post_update_constituents.py`
- **Purpose**: Airflow task orchestration for post-update constituent processing

### Procedure File
- **File**: `dags/benchmark_aggregates_holdings/procedure_post_update_constituents.py`
- **Purpose**: Core business logic for constituent updates and link table maintenance

---

## 1. Tables Used as Inputs

| Table Name                              | Description                                                                                                          |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **DMIR.tblDMIRBRSBenchmarkConstituent** | Benchmark constituent records: may contain unresolved instruments (numInstId = -1) needing mapping updates         |
| **DMIR.tblDMIRBRSInstrument**          | Instrument master: provides mappings from ISIN codes and internal Aladdin codes to instrument IDs                  |
| **DWGN.tblDWGNBenchmarkCharacteristic** | Benchmark characteristics: contains benchmark metadata including composition codes and status information           |
| **DWGN.tblDWGNGPSProduct**             | GPS product catalog: defines active benchmarks with official benchmark IDs and status flags                        |
| **DMIR.TblDMIRLinkFBAToBKGN**          | FBA-BKGN linking table: maintains relationships between FBA benchmark IDs and BKGN composition codes              |

---

## 2. Target Tables

- **DMIR.tblDMIRBRSBenchmarkConstituent**  
  *In Python:* updated via `_update_row()` function with resolved instrument IDs for previously unmapped constituents.  
  *Description:* receives corrected `numInstId` values for records that had -1 (unmapped) instrument IDs.

- **DMIR.TblDMIRLinkFBAToBKGN**  
  *In Python:* maintained via `update_link_fba_to_bkgn_table()` with new benchmark linkages and composition changes.  
  *Description:* receives new FBA benchmark entries and handles composition code changes with proper date management.

---

## 3. Temporary (Staging) Tables / DataFrames

| Staging Table (SQL)                    | Purpose / Description                                                                                                | Equivalent pandas DataFrame(s)                      |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| **#Benchtemp2**                       | ISIN-based instrument mapping: collects unmapped constituents with valid ISIN codes for resolution                 | `df_isin` in `post_update_benchmark_constituents()` |
| **#Benchtemp3**                       | Internal code mapping: collects unmapped constituents with valid internal Aladdin codes for resolution             | `df_internal` in `post_update_benchmark_constituents()` |
| **#bench_to_change**                  | Composition changes: identifies benchmarks with changed composition codes requiring link table updates               | `q_change` query results in `update_link_fba_to_bkgn_table()` |
| *instrument lookup staging*           | Resolved instrument mappings from master data for both ISIN and internal code lookups                               | `df_inst_isin`, `df_inst_internal` in processing functions |
| *merge staging*                       | Joined constituent and instrument data for final update processing                                                   | `df_isin_merged`, `df_internal_merged` for updates |
| *link validation staging*             | Existing FBA codes and composition pairs to avoid duplicate insertions                                              | `existing_fba`, `current_pairs` sets in link processing |

---

## 4. Task Breakdown for the Airflow DAG

| Task Name (`@task`)                              | Description                                                                                                                                                                                                                      | Inputs / Outputs                                                    | Parallelizable?                                    |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- | -------------------------------------------------- |
| **task__check_for_starting_condition**          | Pre-flight check: validates that prerequisite instrument batch processing has completed before starting constituent updates                                                                                                       | **In:** audit_id from params <br>**Out:** validation status        | ❌ (must validate prerequisites before proceeding)  |
| **task__post_update_benchmark_constituents**    | **Part 1**: Fix unmapped instruments via ISIN and internal code lookups <br>**Part 2**: Update FBA-BKGN link table with new benchmarks and composition changes (time-restricted to 0-6h)                                    | **In:** audit_id, current_date <br>**Out:** update counts          | ✔️ (ISIN and internal code processing can be parallel) |

> **Combined Task Analysis**  
> The Python implementation combines both constituent updates and link table management into a single task, unlike the SQL which handles them in separate sections. This provides better atomicity and error handling.

> **Time Restriction**  
> Link table updates only run between 0-6h (night hours) to avoid conflicts with daytime operations, matching the SQL logic.

> **Concurrency Notes**  
> - **ISIN vs Internal Code Processing**: These two mapping strategies can process in parallel since they target different constituent subsets  
> - **Chunked Instrument Lookups**: Internal code lookups are chunked (2000 per batch) and can be parallelized  
> - **Link Table Operations**: New benchmark insertions and composition changes are batched for efficiency  
> - **Update Operations**: Individual constituent updates are processed sequentially to maintain data consistency

---

## 5. High‑Level DAG Structure Diagram

```text
      ┌─────────────────────────────────────────┐
      │ task__check_for_starting_condition      │
      │ (validate instrument batch completion)  │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__post_update_benchmark_constituents│
      │                                         │
      │  ┌─────────────────────────────────────┐│
      │  │ Part 1: Fix Unmapped Instruments   ││
      │  │ • ISIN-based mapping              ││
      │  │ • Internal code mapping           ││
      │  │ • Bulk constituent updates        ││
      │  └─────────────────────────────────────┘│
      │                                         │
      │  ┌─────────────────────────────────────┐│
      │  │ Part 2: FBA-BKGN Link Management   ││
      │  │ • New benchmark detection         ││
      │  │ • Composition change handling     ││
      │  │ • Link table maintenance          ││
      │  └─────────────────────────────────────┘│
      └─────────────────────────────────────────┘
                         ↓
              (Updated constituents & links)
```

---

## 6. Functional Mapping Details

### 1. Missing Instrument Resolution (ISIN-based)
**SQL Section**: Lines 18-35 (ISIN-based instrument mapping)  
**Python Implementation**: `post_update_benchmark_constituents()` - ISIN processing section

**SQL Logic**:
```sql
select distinct numInstId, strInstISINCode
into #Benchtemp2
from DMIR.tblDMIRBRSBenchmarkConstituent 
where datMarketDate >= dateadd(dd, -25, getdate()) 
  and numInstId = -1
  and strInstISINCode is not null

update #Benchtemp2
set numInstId = i.numInstID
From DMIR.tblDMIRBRSInstrument i, #Benchtemp2
where i.strInstISINCode = #Benchtemp2.strInstISINCode
  and i.numInstID > 5000000
```

**Python Equivalent**:
```python
# Collect unmapped constituents with ISIN codes
q_isin = session.query(
    DMIRBRSBenchmarkConstituent.numInstId, 
    DMIRBRSBenchmarkConstituent.strInstISINCode
).filter(
    DMIRBRSBenchmarkConstituent.datMarketDate >= date_limit,
    DMIRBRSBenchmarkConstituent.numInstId == -1,
    DMIRBRSBenchmarkConstituent.strInstISINCode.isnot(None),
)

# Map to instrument IDs
q_inst_isin = session.query(
    DMIRBRSInstrument.numInstID.label("newInstId"),
    DMIRBRSInstrument.strInstISINCode.label("isin"),
).filter(
    DMIRBRSInstrument.numInstID > 5_000_000,
    DMIRBRSInstrument.strInstISINCode.in_(isin_list),
)
```

### 2. Missing Instrument Resolution (Internal Code-based)
**SQL Section**: Lines 39-56 (internal code-based instrument mapping)  
**Python Implementation**: `post_update_benchmark_constituents()` - Internal code processing section

**SQL Logic**:
```sql
select distinct numInstId, strtInstInternalCode
into #Benchtemp3
from DMIR.tblDMIRBRSBenchmarkConstituent 
where datMarketDate >= dateadd(dd, -25, getdate()) 
  and numInstId = -1
  and strtInstInternalCode is not null

update #Benchtemp3
set numInstId = i.numInstID
From DMIR.tblDMIRBRSInstrument i, #Benchtemp3
where i.strInstAladdin = #Benchtemp3.strtInstInternalCode
  and i.numInstID > 5000000
```

**Python Equivalent**:
```python
# Collect unmapped constituents with internal codes
q_internal = session.query(
    DMIRBRSBenchmarkConstituent.numInstId, 
    DMIRBRSBenchmarkConstituent.strtInstInternalCode
).filter(
    DMIRBRSBenchmarkConstituent.datMarketDate >= date_limit,
    DMIRBRSBenchmarkConstituent.numInstId == -1,
    DMIRBRSBenchmarkConstituent.strtInstInternalCode.isnot(None),
)

# Chunked processing for large internal code lists
chunks = [internal_list[i:i+2000] for i in range(0, len(internal_list), 2000)]
for chunk in chunks:
    q_inst_internal = session.query(
        DMIRBRSInstrument.numInstID.label("newInstId"),
        DMIRBRSInstrument.strInstAladdin.label("internalCode"),
    ).filter(
        DMIRBRSInstrument.numInstID > 5_000_000, 
        DMIRBRSInstrument.strInstAladdin.in_(chunk)
    )
```

### 3. FBA-BKGN Link Table Management
**SQL Section**: Lines 75-140 (new benchmark insertion and composition change handling)  
**Python Implementation**: `update_link_fba_to_bkgn_table()`

**SQL Logic**:
```sql
-- Time restriction check
if @hour < 6
BEGIN
    -- Insert new benchmarks
    INSERT INTO "DMIR"."TblDMIRLinkFBAToBKGN"
    select distinct cast(strBnchmkCd as Integer), 'ALADDIN', null, 
           cast(dateadd(dd, -10, getdate()) as date), null, strCompositionCd
    from DWGN.tblDWGNBenchmarkCharacteristic 
    where strBnchmkCd not in (
        select cast(numBenchIdFBA as varchar(10))
        from DMIR.TblDMIRLinkFBAToBKGN 
        where strSource = 'ALADDIN'
    )
    and strBnchmkStat = '12'
    and strCompositionCd is not null
```

**Python Equivalent**:
```python
# Time restriction check
now, *_ = get_date_pivot(audit_id)
if not (0 <= now.hour < 6):
    print("It's not between 0 and 6h. Skipped.")
    return

# Get existing FBA codes to avoid duplicates
existing_fba = {
    row[0] for row in session.query(DMIRLinkFBAToBKGN.numBenchIdFBA)
    .filter(DMIRLinkFBAToBKGN.strSource == "ALADDIN").all()
}

# Find new benchmarks to insert
q_new = session.query(
    DWGNBenchmarkCharacteristic.strBnchmkCd,
    DWGNBenchmarkCharacteristic.strCompositionCd,
).join(
    DWGNGPSProduct,
    DWGNGPSProduct.strOfficialBnchmkID == DWGNBenchmarkCharacteristic.strBnchmkCd,
).filter(
    DWGNBenchmarkCharacteristic.strBnchmkStat == "12",
    DWGNBenchmarkCharacteristic.strCompositionCd.isnot(None),
    DWGNGPSProduct.strStatus == "G",
)
```

### 4. Composition Change Management
**SQL Section**: Lines 100-140 (composition code change detection and handling)  
**Python Implementation**: Composition change logic in `update_link_fba_to_bkgn_table()`

**SQL Logic**:
```sql
-- Detect composition changes
select ip.numBenchIdFBA, ip.strCompositionCd as compo_asis, 
       ic.strCompositionCd as compo_tobe, ip.datStartDate
into #bench_to_change
from DMIR.TblDMIRLinkFBAToBKGN ip
inner join DWGN.tblDWGNBenchmarkCharacteristic ic 
    on ic.strBnchmkCd = cast(ip.numBenchIdFBA as varchar(10))
where ip.strSource = 'ALADDIN' 
  and ip.datEndDate is null
  and ic.strBnchmkStat = '12'
  and ip.strCompositionCd <> ic.strCompositionCd
```

**Python Equivalent**:
```python
# Find composition changes
q_change = session.query(
    DMIRLinkFBAToBKGN.numBenchIdFBA,
    DMIRLinkFBAToBKGN.strCompositionCd.label("compo_asis"),
    DWGNBenchmarkCharacteristic.strCompositionCd.label("compo_tobe"),
    DMIRLinkFBAToBKGN.datStartDate,
).join(
    DWGNBenchmarkCharacteristic,
    DWGNBenchmarkCharacteristic.strBnchmkCd == cast(DMIRLinkFBAToBKGN.numBenchIdFBA, String),
).filter(
    DMIRLinkFBAToBKGN.strSource == "ALADDIN",
    DMIRLinkFBAToBKGN.datEndDate.is_(None),
    DWGNBenchmarkCharacteristic.strBnchmkStat == "12",
    DMIRLinkFBAToBKGN.strCompositionCd != DWGNBenchmarkCharacteristic.strCompositionCd,
)

# Handle composition changes with proper date management
for rec in q_change:
    # Close old record and open new one with updated composition
    if rec.compo_asis[:-1] != rec.compo_tobe:  # Ignore cosmetic changes
        # Update end date for old record
        # Insert new record with new composition
```

