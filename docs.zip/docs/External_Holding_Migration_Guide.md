# External Holding Migration Guide

## Overview
This document explains the migration from the SQL stored procedure `stpDMIRExternalBenchmark` to the Python workflow/procedure pair: `workflow_bench_external_benchmarks.py` and `procedure_external_holding.py`.

## SQL Source
- **Stored Procedure**: `stpDMIRExternalBenchmark`
- **SQL File**: `dags/sql/stpDMIRExternalBenchmark.sql`
- **Lines Covered**: 1-587 (complete external benchmark holdings processing with forex mapping)
- **Purpose**: Generate external benchmark holdings data from BRS benchmark constituents with comprehensive forex instrument mappings

## Python Implementation

### Workflow File
- **File**: `dags/benchmark_aggregates_holdings/workflow_bench_external_benchmarks.py`
- **Purpose**: Airflow task orchestration for external benchmark processing

### Procedure File
- **File**: `dags/benchmark_aggregates_holdings/procedure_external_holding.py`
- **Purpose**: Core business logic for external benchmark data processing and forex instrument mapping

---

## 1. Tables Used as Inputs

| Table Name                              | Description                                                                                                          |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **DMIR.tblDMIRSpecialFunds**           | Special fund configurations: ISIN mappings with composition codes, currencies, and validity periods                 |
| **DWGN.tblDWGNBenchmarkConstituents**  | BRS benchmark data: constituent holdings with instruments, quantities, prices, and market values                    |
| **DMIR.tblDMIRBRSInstrument**          | Instrument master: complete instrument metadata including identifiers and currency information                      |

---

## 2. Target Tables

- **DMIR.tblDMIRExternalSpecialHolding**  
  *In Python:* populated via time-controlled processing with parallel forex instrument mapping.  
  *Description:* External benchmark holdings with forex instruments mapped to cash equivalents for specialized external funds.

---

## 3. Temporary (Staging) Tables / DataFrames

| Staging Table (SQL)                    | Purpose / Description                                                                                                | Equivalent pandas DataFrame(s)                      |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| **#scopeBRSExt**                      | Active special funds scope for current processing period                                                            | `scope_df` - filtered special funds with validity   |
| **#scopebrs2**                       | Maximum benchmark dates per composition code                                                                         | `max_dates_df` - aggregated max dates by composition |
| **#res**                              | Aggregated holdings totals for AUM calculation                                                                      | `totals_df` - grouped holdings for AUM update       |

---

## 4. Key Transformations

### SQL Approach
```sql
-- Step 1: Define active special funds scope
SELECT DISTINCT strSPISINCode, strCompositionCd, strPortfCurr, 
       min(convert(Char(10),datValidBegin)), max(convert(char(10),datValidEnd))
FROM DMIR.tblDMIRSpecialFunds
WHERE Previous_month_end BETWEEN datValidBegin AND datValidEnd

-- Step 2: Find maximum benchmark date per composition
SELECT max(C.datValuDt) as max_benchmark_date, C.strCompositionCd
FROM DWGN.tblDWGNBenchmarkConstituents C, #scopeBRSExt S
WHERE C.strCompositionCd = S.strCompositionCd
AND C.datValuDt <= S.Previous_month_end

-- Step 3: Insert holdings with aggregation
INSERT INTO DMIR.tblDMIRExternalSpecialHolding
SELECT E.strSPISINCode, C.datValuDt, C.strInstrmtCd,
       sum(C.numMktCptlstCompositionCcy) as numHoldValuInPortfCur,
       sum(C.numQty) as numHoldQuantity, avg(C.numCttPx) as numHoldPrice
FROM #scopeBRSExt E
INNER JOIN DWGN.tblDWGNBenchmarkConstituents C
INNER JOIN #scopebrs2 s3 ON max_benchmark_date match
```

### Python Approach
```python
def process_external_benchmarks(audit_id: int, date: str) -> Dict:
    # Time window validation (0-4 AM only)
    if not _is_processing_time_valid():
        return {"status": "skipped", "reason": "outside processing window"}
    
    # Step 1: Get active special funds scope
    scope_df = _get_special_funds_scope(date)
    
    # Step 2: Find maximum benchmark dates
    max_dates_df = _get_max_benchmark_dates(scope_df, date)
    
    # Step 3: Process holdings with parallel execution
    with ProcessPoolExecutor(max_workers=24) as executor:
        holdings_results = executor.map(_process_benchmark_batch, batched_data)
    
    # Step 4: Apply forex mappings
    final_df = _apply_forex_mappings(consolidated_df)
    
    return _bulk_insert_holdings(final_df, audit_id)
```

---

## 5. Task Breakdown for the Airflow DAG

| Task Name (`@task`)                              | Description                                                                                                                                                                                                                      | Inputs / Outputs                                                    | Parallelizable?                                    |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- | -------------------------------------------------- |
| **task__process_external_benchmarks**          | Complete external benchmark processing: validates time window, processes fund compositions, maps instruments, and generates holdings data                                                                                        | **In:** audit_id <br>**Out:** processing status and metrics        | ❌ (single comprehensive processing task)          |

---

## 6. High‑Level DAG Structure Diagram

```text
      ┌─────────────────────────────────────────┐
      │ task__process_external_benchmarks       │
      │ • Time window validation (0-4 AM)       │
      │ • Special funds scope determination     │
      │ • Benchmark constituents processing     │
      │ • Parallel instrument mapping          │
      │ • Holdings aggregation and insertion    │
      │ • AUM calculations and updates          │
      │ • Forex instrument substitution        │
      └─────────────────────────────────────────┘
```

**Implementation Details:**

**task__process_external_benchmarks:**
- Calls `process_external_benchmarks(audit_id)` from procedure module
- Validates execution time window (0-4 AM) before processing
- Handles complete external benchmark processing pipeline internally
- Returns processing status and handles all error conditions

---

## 7. Functional Mapping

### 7.1 Time Window Validation
**SQL Implementation:** No time restriction enforcement
**Python Implementation:**
```python
def _is_processing_time_valid() -> bool:
    """Enforce 0-4 AM processing window for external benchmarks"""
    current_hour = datetime.now().hour
    return 0 <= current_hour <= 4
```

### 7.2 Previous Month End Calculation
**SQL Implementation:**
```sql
dateadd(dd,-(day(@dateToday)),@dateToday) as Previous_month_end
```
**Python Implementation:**
```python
def _calculate_previous_month_end(processing_date: str) -> datetime:
    """Calculate last day of previous month"""
    date_obj = datetime.strptime(processing_date, '%Y-%m-%d')
    first_of_month = date_obj.replace(day=1)
    previous_month_end = first_of_month - timedelta(days=1)
    return previous_month_end
```

### 7.3 Scope Filtering
**SQL Implementation:**
```sql
WHERE dateadd(dd,-(day(@dateToday)),@dateToday) 
BETWEEN cast(datValidBegin as datetime) AND cast(datValidEnd as datetime) 
OR datValidEnd is null
```
**Python Implementation:**
```python
def _filter_active_funds(df: pd.DataFrame, reference_date: datetime) -> pd.DataFrame:
    """Filter for funds active on reference date"""
    active_mask = (
        (df['datValidBegin'] <= reference_date) &
        ((df['datValidEnd'] >= reference_date) | df['datValidEnd'].isna())
    )
    return df[active_mask]
```

### 7.4 Parallel Processing Setup
**SQL Implementation:** Sequential processing with temp tables
**Python Implementation:**
```python
def _setup_parallel_processing(scope_df: pd.DataFrame) -> List[Dict]:
    """Prepare batches for parallel processing"""
    batches = []
    
    for composition_cd in scope_df['strCompositionCd'].unique():
        composition_scope = scope_df[
            scope_df['strCompositionCd'] == composition_cd
        ]
        
        batch = {
            'composition_cd': composition_cd,
            'scope_records': composition_scope,
            'worker_id': len(batches) % 24  # Distribute across 24 workers
        }
        batches.append(batch)
    
    return batches
```

### 7.5 Forex Instrument Mapping
**SQL Implementation:** 35 individual UPDATE statements for each currency
```sql
-- EUR Forex
UPDATE DMIR.tblDMIRExternalSpecialHolding
SET numInstID = 5071660, strInstAladdin = 'XEUR00002'
WHERE i.numInstTypeId in (450, 451) AND ext.strInstCurrCode = 'EUR'

-- JPY Forex  
UPDATE DMIR.tblDMIRExternalSpecialHolding
SET numInstID = 5071671, strInstAladdin = 'XJPY00002'  
WHERE i.numInstTypeId in (450, 451) AND ext.strInstCurrCode = 'JPY'
```

**Python Implementation:**
```python
def _apply_forex_mappings(holdings_df: pd.DataFrame) -> pd.DataFrame:
    """Apply forex instrument mappings for instrument types 450/451"""
    
    forex_mapping = {
        'EUR': {'inst_id': 5071660, 'aladdin_code': 'XEUR00002'},
        'JPY': {'inst_id': 5071671, 'aladdin_code': 'XJPY00002'},
        'USD': {'inst_id': 5071707, 'aladdin_code': 'XUSD00000'},
        'ARS': {'inst_id': 5071639, 'aladdin_code': 'XARS00002'},
        'CHF': {'inst_id': 5071651, 'aladdin_code': 'XCHF00007'},
        'GBP': {'inst_id': 5071661, 'aladdin_code': 'XGBP00002'},
        'AUD': {'inst_id': 5071640, 'aladdin_code': 'XAUD00001'},
        'SEK': {'inst_id': 5071701, 'aladdin_code': 'XSEK00004'},
        'NOK': {'inst_id': 5071685, 'aladdin_code': 'XNOK00004'},
        'CAD': {'inst_id': 5071650, 'aladdin_code': 'XCAD00009'},
        'SGD': {'inst_id': 5071702, 'aladdin_code': 'XSGD00008'},
        'ZAR': {'inst_id': 5071712, 'aladdin_code': 'XZAR00007'},
        'HKD': {'inst_id': 5071664, 'aladdin_code': 'XHKD00007'},
        'DKK': {'inst_id': 5071657, 'aladdin_code': 'XDKK00000'},
        'NZD': {'inst_id': 5071686, 'aladdin_code': 'XNZD00008'},
        'BRL': {'inst_id': 5071647, 'aladdin_code': 'XBRL00005'},
        'MXN': {'inst_id': 5071681, 'aladdin_code': 'XMXN00000'},
        'IDR': {'inst_id': 5071667, 'aladdin_code': 'XIDR00002'},
        'INR': {'inst_id': 5071669, 'aladdin_code': 'XINR00001'},
        'HUF': {'inst_id': 5071666, 'aladdin_code': 'XHUF00001'},
        'KRW': {'inst_id': 5071673, 'aladdin_code': 'XKRW00001'},
        'PLN': {'inst_id': 5071692, 'aladdin_code': 'XPLN00006'},
        'RUB': {'inst_id': 5071698, 'aladdin_code': 'XRUB00008'},
        'TRY': {'inst_id': 5071704, 'aladdin_code': 'XTRY00008'},
        'ILS': {'inst_id': 5071668, 'aladdin_code': 'XILS00001'},
        'TWD': {'inst_id': 5071705, 'aladdin_code': 'XTWD00008'},
        'COP': {'inst_id': 5071655, 'aladdin_code': 'XCOP00007'},
        'CZK': {'inst_id': 5071656, 'aladdin_code': 'XCZK00006'},
        'CNY': {'inst_id': 5071654, 'aladdin_code': 'XCNY00009'},
        'MYR': {'inst_id': 5071682, 'aladdin_code': 'XMYR00000'},
        'PHP': {'inst_id': 5071690, 'aladdin_code': 'XPHP00006'},
        'THB': {'inst_id': 5071703, 'aladdin_code': 'XTHB00009'},
        'PEN': {'inst_id': 5071688, 'aladdin_code': 'XPEN00004'},
        'CLP': {'inst_id': 5071652, 'aladdin_code': 'XCLP00000'},
        'RON': {'inst_id': 5071696, 'aladdin_code': 'XRON00009'},
        'SAR': {'inst_id': 5071700, 'aladdin_code': 'XSAR00003'}
    }
    
    # Apply forex mappings for instruments with types 450/451
    forex_mask = holdings_df['numInstTypeId'].isin([450, 451])
    
    for currency, mapping in forex_mapping.items():
        currency_mask = (
            forex_mask & 
            (holdings_df['strInstCurrCode'] == currency)
        )
        
        if currency_mask.any():
            holdings_df.loc[currency_mask, 'numInstID'] = mapping['inst_id']
            holdings_df.loc[currency_mask, 'strInstAladdin'] = mapping['aladdin_code']
    
    return holdings_df
```
