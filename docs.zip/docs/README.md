# Migration Documentation Index

This directory contains detailed migration guides for each SQL-to-Python conversion in the project.

## Available Migration Guides

### 1. Benchmark Data BRS
- **Guide**: [Benchmark_Data_BRS_Migration_Guide.md](./Benchmark_Data_BRS_Migration_Guide.md)
- **SQL Source**: `stpDMIRBenchData_BRS`
- **SQL File**: `dags/sql/stpDMIRBenchData_BRS.sql`
- **Python Files**:
  - `dags/benchmark_data_brs/workflow_benchmark_data.py` 
  - `dags/benchmark_data_brs/procedure_benchmark_data.py`
- **Purpose**: BRS benchmark constituent data processing with market cap calculations

### 2. Post Update Constituents
- **Guide**: [Post_Update_Constituents_Migration_Guide.md](./Post_Update_Constituents_Migration_Guide.md)
- **SQL Source**: `stpDMIRBenchmarkAggregate` (part 1)
- **SQL File**: `dags/sql/stpDMIRBenchmarkAggregate.sql`
- **Python Files**:
  - `dags/benchmark_aggregates_holdings/workflow_post_update_constituents.py`
  - `dags/benchmark_aggregates_holdings/procedure_post_update_constituents.py`
- **Purpose**: Constituent update processing and data validation after BRS import

### 3. Benchmark Scope
- **Guide**: [Benchmark_Scope_Migration_Guide.md](./Benchmark_Scope_Migration_Guide.md)
- **SQL Source**: `stpDMIRBenchmarkAggregate_BRS` (part 1)
- **SQL File**: `dags/sql/stpDMIRBenchmarkAggregate_BRS.sql`
- **Python Files**:
  - `dags/benchmark_aggregates_holdings/workflow_bench_scope.py`
  - `dags/benchmark_aggregates_holdings/procedure_bench_scope.py`
- **Purpose**: Benchmark scope identification and universe definition for processing

### 4. Benchmark Instrument Indicators  
- **Guide**: [Benchmark_Instrument_Indicators_Migration_Guide.md](./Benchmark_Instrument_Indicators_Migration_Guide.md)
- **SQL Source**: `stpDMIRBenchmarkAggregate_BRS` (part 2)
- **SQL File**: `dags/sql/stpDMIRBenchmarkAggregate_BRS.sql`
- **Python Files**:
  - `dags/benchmark_aggregates_holdings/workflow_bench_instr_indicators.py`
  - `dags/benchmark_aggregates_holdings/procedure_bench_instr_indicators.py`
- **Purpose**: Instrument-level indicator computation with multi-stage processing pipeline (BKGN_1 through BKGN_7)

### 5. Benchmark Indicators
- **Guide**: [Benchmark_Indicators_Migration_Guide.md](./Benchmark_Indicators_Migration_Guide.md)
- **SQL Source**: `stpDMIRBenchmarkAggregate_BRS` (part 3)
- **SQL File**: `dags/sql/stpDMIRBenchmarkAggregate_BRS.sql`
- **Python Files**:
  - `dags/benchmark_aggregates_holdings/workflow_bench_indicators.py`
  - `dags/benchmark_aggregates_holdings/procedure_bench_indicators.py`
- **Purpose**: Benchmark-level aggregate indicator computation and rating analysis

### 6. API Benchmark Holdings
- **Guide**: [API_Bench_Holding_Migration_Guide.md](./API_Bench_Holding_Migration_Guide.md)
- **SQL Source**: `stpDMIRAPIBenchHolding`
- **SQL File**: `dags/sql/stpDMIRAPIBenchHolding.sql`
- **Python Files**: 
  - `dags/benchmark_aggregates_holdings/workflow_api_bench_holding.py`
  - `dags/benchmark_aggregates_holdings/procedure_api_bench_holding.py`
- **Purpose**: API benchmark holdings processing with complex rating logic and derivative handling

### 7. External Holdings
- **Guide**: [External_Holding_Migration_Guide.md](./External_Holding_Migration_Guide.md)
- **SQL Source**: `stpDMIRBenchmarkAggregate` (part 2)
- **SQL File**: `dags/sql/stpDMIRBenchmarkAggregate.sql`
- **Python Files**:
  - `dags/benchmark_aggregates_holdings/workflow_external_holding.py`
  - `dags/benchmark_aggregates_holdings/procedure_external_holding.py`
- **Purpose**: External benchmark data processing and integration with internal holdings