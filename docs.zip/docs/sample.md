## 1. Tables Used as Inputs

| Table Name                       | Description                                                                                                          |
| -------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **DMIR.tblDMIRTransparizLTWrk**  | Source look‑through holdings: per‑period, per‑portfolio positions with values, quantities, currencies and flags.    |
| **DMIR.tblDMIRBRSInstrument**    | Instrument master: maps `numInstID` → `numInstTypeId`.                                                               |
| **DMIR.tblDMIRInstrumentIRType** | Instrument‑IR‑type metadata: defines each `numInstrTypeID`’s `strReportingType` and `strInstrumentTypeIRName`.     |
| **DMIR.tblDMIRMonitoringLT**     | Monitoring table: stores fund/instrument-level assignments (`numReportLevelID`, `datLastModifDate`) over time.     |

---

## 2. Target Tables

- **DMIR.tblDMIRTransparizLTWrk**  
  *In Python:* represented by the final DataFrame returned by `process_final_step_3`.  
  *Description:* the working table is conceptually updated in place—flags, level IDs and deletions—and then persisted downstream.

- **DMIR.tblDMIRMonitoringLT**  
  *In Python:* updated in `update_monitoring_table_after_lt` via SQLAlchemy `UPDATE` calls.  
  *Description:* receives the final `numReportLevelID` and `datLastModifDate` for all rows where `strInstCatName = 'FUND'`.

---

## 3. Temporary (Staging) Tables / DataFrames

| Staging Table (SQL)                         | Purpose / Description                                                                                                                              | Equivalent pandas DataFrame(s)       |
| ------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------ |
| **#step_final_1**                           | Compute per‑group max(`numInventoryLevel`)                                                                                                        | internal `df` in `process_final_step_1` (with a `maxInventoryLevel` column) |
| **#lkp_tblDMIRTransparizLT_LowestLevel**    | All rows with `numLowestInventoryflag = 1` plus a `ROW_NUMBER()` as `numReportLevelID`                                                             | `df_lowest` in `process_final_step_2`  |
| **#lkp**                                    | Simplified lookup of `(strReportPeriod, strPortfLevelID, strInvestedInInstrID, strInvestedInPortfISOCur, numReportLevelID)`                         | `df_lkp` in `process_final_step_3`      |
| **#master**                                 | Non‑lowest rows that either have no invested‑in‑portfolio or have underlying/data‑presence flags off                                                | `df_master` in `process_final_step_3`   |
| **#step_final_3**                           | Union of (a) direct lookup rows and (b) aggregated rows to assign final `numReportLevelID` for all non‑lowest rows                                 | `df_step_final_3` in `process_final_step_3` |
| *implicit join staging*                     | Merged with `df_instrument` and `df_instrument_irtype` to identify and drop forex/zero‑value rows                                                   | `df_merged` → `df_final` in `process_final_step_3` |

---

## 4. Task Breakdown for the Airflow DAG

| Task Name (`@task`)                        | Description                                                                                                                                                                                                                                                            | Inputs / Outputs                                                 | Parallelizable?                                                                                                                        |
| ------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| **task__process_final_step_1**              | Implements `process_final_step_1()`:  
1. Compute `maxInventoryLevel` per group.  
2. Set `numLowestInventoryflag = 1` and `datLastModifDate = now` where `numInventoryLevel == maxInventoryLevel`.                                            | **In:** `df_wrk` (loaded from XCom)  
**Out:** `df_wrk_1` (flags & dates updated)                       | ❌ (must run before any level‑ID assignment)                                                                                                 |
| **task__process_final_step_2**              | Implements `process_final_step_2()`:  
1. Extract `df_lowest` where `numLowestInventoryflag == 1`.  
2. Sort per group by `(strPortfLevelID DESC, strInvestedInPortfID DESC, strInvestedInInstrID, strInvestedInPortfISOCur)`.  
3. Assign `numReportLevelID = row_number()` within each group.  
4. Merge back into `df_wrk_1` to produce `df_wrk_2`. | **In:** `df_wrk_1`  
**Out:** `df_wrk_2` (with `numReportLevelID` set for lowest rows) | ❌ (depends on task__process_final_step_1)                                                                                             |
| **task__load_instrument_and_irtype**        | Implements `load_instrument_and_irtype()`:  
1. Chunk and query `DMIRBRSInstrument` → `df_instrument`.  
2. Chunk and query `DMIRInstrumentIRType` → `df_instrument_irtype`.                                                                                                  | **In:** none (besides DB connection)  
**Out:** `df_instrument`, `df_instrument_irtype`                 | ✔️  (independent once `df_wrk_2` exists; inside, use `concurrent.futures.ThreadPoolExecutor` to parallelize chunk queries) |
| **task__process_final_step_3**              | Implements `process_final_step_3()`:  
1. Build `df_lkp` and `df_master`.  
2. **Parallel**:  
   - Part 1: left‑join `df_master` ←→ `df_lkp`.  
   - Part 2: filter non‑lowest underlying rows, aggregate `min(numReportLevelID)` via `distinct_lkp`.  
3. `union` → `df_step_final_3`.  
4. Merge into `df_wrk_2` to update all `numReportLevelID`.  
5. Delete unmapped (`numInstID=-1 & amt=0`) rows.  
6. Merge with `df_instrument` & filter out forex/zero‑value rows → `df_final`. | **In:** `df_wrk_2`, `df_instrument`, `df_instrument_irtype`  
**Out:** `df_wrk_final`                                          | ✔️  (Parts 1 & 2 can each run in separate threads or processes)                                                         |
| **task__update_monitoring_table_after_lt** | Implements `update_monitoring_table_after_lt()`:  
1. Filter `df_wrk_2` to `strInstCatName == 'FUND'`.  
2. Batch‑update `DMIRMonitoringLT` for each `(strReportPeriod, strPortfLevelID, strInvestedInInstrID)` with non‑null `numReportLevelID`.                                                             | **In:** `df_wrk_2`  
**Out:** integer row‑count                                          | ✔️  (can run as soon as `df_wrk_2` is available, in parallel with load/step 3)                                         |

> **Concurrency Notes**  
> - **Chunked queries** in `load_instrument_and_irtype` can use a thread pool to speed up DB round‑trips.  
> - Within **process_final_step_3**, compute the two parts (direct lookup vs. aggregated lookup) in parallel and then `pd.concat`.  
> - **Monitoring updates** in `update_monitoring_table_after_lt` can be batched (e.g. bulk‑mapping or in‑clause updates) or parallelized by slicing the group list.

---

## 5. High‑Level DAG Structure Diagram

```text
      ┌───────────────────────────────────────────┐
      │ task__process_final_step_1 (step1)      │
      └───────────────────────────────────────────┘
                             ↓
      ┌───────────────────────────────────────────┐
      │ task__process_final_step_2 (step2)      │
      └───────────────────────────────────────────┘
                       ↙            ↘
           ┌─────────────────┐    ┌──────────────────────────────────────┐
           │ task__load_     │    │ task__update_monitoring_table_after_lt │
           │ instrument_and_ │    │ (monitoring updates)                  │
           │ irtype (step3)  │    └──────────────────────────────────────┘
           └─────────────────┘                 ↓
                       ↓                       (independent)
      ┌───────────────────────────────────────────┐
      │ task__process_final_step_3 (step4)      │
      └───────────────────────────────────────────┘
                             ↓
                     (df_wrk_final)
