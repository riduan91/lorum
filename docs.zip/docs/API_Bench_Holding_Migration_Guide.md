# API Bench Holding Migration Guide

## Overview
This document explains the migration from the SQL stored procedure `stpDMIRAPIBenchHolding` to the Python workflow/procedure pair: `workflow_api_bench_holding.py` and `procedure_api_bench_holding.py`.

## SQL Source
- **Stored Procedure**: `stpDMIRAPIBenchHolding`
- **SQL File**: `dags/sql/stpDMIRAPIBenchHolding.sql`
- **Lines Covered**: 1-1685 (complete API benchmark holdings processing with derivative overrides)
- **Purpose**: Generate API-ready benchmark holdings data with comprehensive instrument details, sector classifications, and derivative handling

## Python Implementation

### Workflow File
- **File**: `dags/benchmark_aggregates_holdings/workflow_api_bench_holding.py`
- **Purpose**: Airflow task orchestration for API benchmark holding processing

### Procedure File
- **File**: `dags/benchmark_aggregates_holdings/procedure_api_bench_holding.py`
- **Purpose**: Core business logic for API data preparation and derivative processing

---

## 1. Tables Used as Inputs

| Table Name                              | Description                                                                                                          |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **DMIR.tblDMIRBRSBenchmarkConstituent** | Source constituents: benchmark positions with instruments, weights, quantities, and market data                     |
| **DMIR.tblDMIRBRSInstrument**          | Instrument master: complete instrument metadata including identifiers, dates, and contract details                  |
| **DMIR.tblDMIRBRSBenchInstrIndicators** | Instrument indicators: analytics data including duration, yield, ratings, and contribution metrics                  |
| **DMIR.tblDMIRBRSBenchIndicators**     | Benchmark indicators: benchmark-level aggregated indicators for scope determination                                 |
| **DMIR.tblDMIRBRSInstSector**          | Sector classifications: multi-hierarchy sector data (Bloomberg, MSCI, ICB, Barclays, JPM)                         |
| **DMIR.tblDMIRBreakdownDerivativesParam** | Derivative overrides: parameter table for derivative instrument field overrides                                    |
| **DMIR.tblDMIRBRSInstRating**          | Instrument ratings: credit ratings from multiple agencies for instruments                                           |
| **DMIR.tblDMIRBRSIssuerRating**        | Issuer ratings: credit ratings for issuers as fallback when instrument ratings unavailable                         |
| **DMIR.tblDMIRFundCountryOfRisk**      | Country risk mapping: country of risk assignments for instruments                                                   |

---

## 2. Target Tables

- **DMIR.tblDMIRAPIBenchHolding**  
  *In Python:* populated via comprehensive data consolidation pipeline with derivative overrides.  
  *Description:* API-ready benchmark holdings with complete instrument details, sector breakdowns, analytics, ratings, and ESG data for external consumption.

---

## 3. Temporary (Staging) Tables / DataFrames

| Staging Table (SQL)                    | Purpose / Description                                                                                                | Equivalent pandas DataFrame(s)                      |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| **#scope_api**                        | API scope: existing API holdings within calculation horizon for incremental processing                              | `scope_api_df` in `compute_scope_for_api_bench_holding()` |
| **#scope_aggr**                       | Aggregation scope: benchmarks from benchmark indicators requiring API data refresh                                 | `scope_aggr_df` in scope computation functions       |
| **#scope**                            | Combined scope: merged and filtered scope for processing based on audit ID comparisons                             | `final_scope_df` in scope processing                 |
| **#tblDMIRBRSInstSector**             | Sector consolidation: aggregated sector data from multiple hierarchies to avoid duplicates                        | `df_sector_consolidated` in sector processing        |
| **#tblDMIRAPIBenchHolding**           | Main staging: comprehensive benchmark holdings data before derivative overrides                                    | `df_api_holdings` in main processing pipeline        |
| **derivative overrides staging**      | Derivative processing: temporary data for applying parameter-driven overrides to derivative instruments            | `df_derivative_overrides` in derivative functions    |
| **rating consolidation staging**      | Rating integration: combined instrument and issuer ratings with fallback logic                                     | `df_ratings_combined` in rating processing          |
| **analytics staging**                 | Analytics integration:

---

## 4. Task Breakdown for the Airflow DAG

| Task Name (`@task`)                              | Description                                                                                                                                                                                                                      | Inputs / Outputs                                                    | Parallelizable?                                    |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- | -------------------------------------------------- |
| **task__start_group**                           | Initialize API holdings processing: log workflow start and validate audit parameters                                                                                                                                           | **In:** audit_id, calc_horizon <br>**Out:** initialization status  | ❌ (workflow initialization)                       |
| **task__compute_scope_for_api_bench_holding**   | Scope determination: identify benchmarks requiring API data updates based on calculation horizon and audit ID comparisons                                                                                                      | **In:** audit parameters <br>**Out:** processing scope DataFrame   | ❌ (scope defines processing universe)             |
| **task__consolidate_sector_data**               | Sector consolidation: aggregate multi-hierarchy sector data to eliminate duplicates and prepare for efficient merging                                                                                                          | **In:** scope data <br>**Out:** consolidated sector DataFrame      | ✔️ (sector hierarchies can be processed in parallel) |
| **task__extract_base_holdings_data**           | Base data extraction: retrieve benchmark constituents with instrument master data, identifiers, and basic attributes                                                                                                           | **In:** scope DataFrame <br>**Out:** base holdings data            | ✔️ (benchmarks can be processed in parallel)       |
| **task__integrate_instrument_indicators**      | Analytics integration: merge instrument indicators including duration, yield, convexity, ratings, and contribution metrics                                                                                                     | **In:** base holdings <br>**Out:** holdings with analytics         | ✔️ (analytics lookups can be parallelized)         |
| **task__apply_sector_classifications**         | Sector classification: apply consolidated sector data across multiple hierarchies (Bloomberg, MSCI, ICB, Barclays, JPM)                                                                                                       | **In:** holdings with analytics <br>**Out:** holdings with sectors | ✔️ (sector applications can be parallelized)       |
| **task__integrate_rating_data**                | Rating integration: apply instrument and issuer ratings with complex fallback logic and multiple agency support                                                                                                               | **In:** holdings with sectors <br>**Out:** holdings with ratings   | ✔️ (rating agencies can be processed in parallel)  |
| **task__apply_derivative_overrides**           | Derivative processing: apply parameter-driven field overrides for derivative instruments including maturity, sectors, countries, and ratings                                                                                  | **In:** holdings with ratings <br>**Out:** holdings with overrides | ✔️ (derivative types can be processed in parallel) |
| **task__calculate_esg_and_analytics**          | ESG and analytics: integrate sustainability metrics and calculate remaining analytical fields                                                                                                                                  | **In:** holdings with overrides <br>**Out:** complete holdings     | ✔️ (ESG metrics can be calculated in parallel)     |
| **task__delete_existing_api_holdings**         | Data cleanup: delete existing API holdings for processed scope to ensure clean incremental updates                                                                                                                             | **In:** processing scope <br>**Out:** deletion status              | ❌ (database operations must be atomic)            |
| **task__insert_final_api_holdings**            | Data persistence: bulk insert final API holdings data with comprehensive instrument details                                                                                                                                    | **In:** complete holdings <br>**Out:** insertion status            | ❌ (final insertion must be atomic)                |
| **task__validate_api_holdings**                | Post-processing validation: validate data quality, completeness, and consistency of API holdings                                                                                                                               | **In:** inserted data <br>**Out:** validation results              | ✔️ (validation rules can be checked in parallel)   |
| **task__end_group**                             | Workflow completion: log completion statistics and processing metrics                                                                                                                                                          | **In:** final status <br>**Out:** completion metrics               | ❌ (workflow finalization)                         |

> **Derivative Override Architecture**  
> The derivative processing system implements sophisticated field overrides:
> - **Parameter-Driven**: Override rules defined in `tblDMIRBreakdownDerivativesParam` table
> - **Field-Specific**: Selective overrides for maturity, sectors, countries, and ratings
> - **Type-Based Logic**: Different override patterns for different derivative instrument types
> - **Fallback Hierarchy**: Complex logic for determining override values with multiple fallback levels

> **Multi-Hierarchy Sector Integration**  
> Sector classification involves multiple sector hierarchies:
> - **Bloomberg Sectors**: 4-level Bloomberg sector classification with derivatives handling
> - **MSCI Sectors**: MSCI sector hierarchy with special derivative categorization  
> - **ICB Sectors**: Industry Classification Benchmark sector assignments
> - **Barclays Sectors**: Barclays sector classification for fixed income instruments
> - **JPM Sectors**: JP Morgan sector hierarchy for specialized instrument types

> **Rating Consolidation Workflow**  
> Rating integration implements complex fallback logic:
> - **Primary Source**: Instrument-specific ratings from rating agencies
> - **Issuer Fallback**: Issuer ratings when instrument ratings unavailable
> - **Multi-Agency Support**: S&P, Moody's, Fitch, and up to 13 custom rating systems
> - **Derivative Overrides**: Special rating logic for derivative instruments

> **Concurrency Notes**  
> - **Sector Processing**: Different sector hierarchies can be consolidated concurrently
> - **Analytics Integration**: Duration, yield, and risk metrics can be merged in parallel
> - **Rating Agencies**: Multiple rating agency data can be processed simultaneously
> - **Derivative Types**: Different derivative override patterns can be applied concurrently

---

## 5. High‑Level DAG Structure Diagram

```text
      ┌─────────────────────────────────────────┐
      │ task__compute_scope_for_api_bench_holding│
      │ • Query existing API holdings           │
      │ • Identify benchmarks needing updates   │
      │ • Filter by audit ID and date horizon   │
      │ • Save scope to parquet for next task   │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__delete_in_api_bench_holding       │
      │ • Load scope from previous task         │
      │ • Delete existing API holdings data     │
      │ • Log deletion count and metrics        │
      │ • Pass scope DataFrame to next task     │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__process_api_bench_holding         │
      │ • Load scope from previous task         │
      │ • Process benchmark holdings data       │
      │ • Apply derivative overrides            │
      │ • Integrate sector classifications      │
      │ • Apply rating fallback logic           │
      │ • Calculate analytics contributions     │
      │ • Insert final API holdings data        │
      │ • Save results to parquet               │
      └─────────────────────────────────────────┘
```

**Implementation Details:**

**task__compute_scope_for_api_bench_holding:**
- Calls `compute_scope_for_api_bench_holding(audit_id)` from procedure module
- Determines which benchmarks need API data refresh based on audit ID comparisons
- Saves scope DataFrame to parquet file for downstream tasks
- Provides debugging examples and logging

**task__delete_in_api_bench_holding:**
- Loads scope DataFrame from previous task's parquet output
- Calls `delete_api_bench_holdings(scopes_df)` to clean existing data
- Tracks deletion count and pushes metrics to XCom
- Returns scope DataFrame for the processing task

**task__process_api_bench_holding:**
- Loads scope DataFrame from delete task via XCom
- Calls `process_api_bench_holding(scopes_df, audit_id)` for main processing
- Handles all complex logic internally:
  - Derivative override processing
  - Multi-hierarchy sector classification  
  - Rating fallback logic
  - Analytics integration
  - ESG data processing
- Logs processing metrics and saves final results to parquet

> **Task Organization Notes:**
> - **Simple Linear Flow**: The actual implementation follows a clean 3-task linear pipeline
> - **Consolidated Processing**: Complex logic (derivatives, sectors, ratings) is handled within the main processing task
> - **Parquet Handoff**: Tasks communicate via parquet files saved by `save_bench_parquet()` utility
> - **XCom Integration**: Delete task passes scope data via Airflow XCom to processing task
> - **Logging Integration**: All tasks use `log_db()` utility for audit trail and monitoring

---

## 6. Functional Mapping Details

This section provides a detailed mapping of the actual Python implementation for API Bench Holding processing, based on the real code in `procedure_api_bench_holding.py`. The implementation demonstrates a sophisticated parallel processing architecture with comprehensive derivative handling and rating fallback logic.

### 6.1 Scope Determination and Processing Control

**Python Implementation:**
```python
def compute_scope_for_api_bench_holding(audit_id=None, calc_hor=1, end_date=None):
    """
    Computes scope for API bench holdings by identifying benchmarks that need updates.
    
    Processing Logic:
    1. Query existing API holdings in date range (scope_api)  
    2. Query benchmark indicators for period (scope_aggr)
    3. Find benchmarks where aggr.audit_id > api.audit_id (needs refresh)
    4. Add on-demand benchmarks from speed processing parameters
    5. Clean up speed processing parameters after use
    """
    # Calculate date ranges
    last_day_of_month = end_date.replace(day=1) - timedelta(days=1)
    start_date = last_day_of_month + timedelta(days=1) - relativedelta(months=calc_hor)
    
    # Step 1: Get existing API holdings scope
    scope_api_stmt = session.query(
        DMIRAPIBenchHolding.Accountingdate.label("datMarketDate"),
        DMIRAPIBenchHolding.BKGNCode.label("numBenchFBAId"), 
        DMIRAPIBenchHolding.numAuditId,
    ).where(DMIRAPIBenchHolding.Accountingdate.between(start_date, last_day_of_month))
    
    # Step 2: Get benchmark indicators scope
    scope_aggr_stmt = session.query(
        DMIRBRSBenchIndicators.datMarketDate,
        DMIRBRSBenchIndicators.numBenchFBAId,
        DMIRBRSBenchIndicators.strPeriodTypeFlag,
        DMIRBRSBenchIndicators.numAuditId,
    ).where(
        DMIRBRSBenchIndicators.strPeriodTypeFlag == "M",
        DMIRBRSBenchIndicators.datPeriodLastDay.between(start_date, last_day_of_month),
    )
    
    # Step 3: Merge and filter for refreshable benchmarks
    merged_df = pd.merge(scope_aggr_df, scope_api_df, 
                        on=["datMarketDate", "numBenchFBAId"], how="left")
    scope_df = merged_df[
        merged_df["numAuditId_api"].isna() | 
        (merged_df["numAuditId"] > merged_df["numAuditId_api"])
    ]
    
    # Step 4: Add on-demand benchmarks from speed processing parameters
    on_demand_benchmarks = session.execute(
        select(DMIRSpeedProcsParam).where(
            DMIRSpeedProcsParam.strSource == "BM",
            DMIRSpeedProcsParam.numBenchFBAId.isnot(None)
        )
    ).scalars().all()
    
    # Step 5: Clean up speed parameters
    session.execute(text(
        "DELETE FROM tblDMIRSpeedProcsParam WHERE strProcType = 'AGG' AND strSource = 'BM'"
    ))
```

### 6.2 Parallel Processing Architecture

**Python Implementation:**
```python
def process_api_bench_holding(scope_df, audit_id):
    """
    Main processing function using parallel execution for benchmark batches.
    
    Architecture:
    - Groups scope by (benchmark_id, market_date) 
    - Processes each combination in parallel using ProcessPoolExecutor
    - Each worker processes one benchmark-date combination completely
    - Uses chunked queries for efficient bulk data retrieval
    """
    # Create benchmark processing batches
    benchmark_groups = scope_df.groupby(["numBenchFBAId", "datMarketDate"])
    benchmarks = [
        {"numBenchFBAId": bm_id, "datMarketDate": accounting_date}
        for (bm_id, accounting_date), _ in benchmark_groups
    ]
    
    # Process in parallel with up to 48 workers
    with concurrent.futures.ProcessPoolExecutor(max_workers=48) as executor:
        future_to_batch = {
            executor.submit(_process_benchmark_batch, i, benchmark, audit_id): i
            for i, benchmark in enumerate(benchmarks)
        }
        
        for future in concurrent.futures.as_completed(future_to_batch):
            row_count_for_batch = future.result()
            if row_count_for_batch is not None:
                count += row_count_for_batch
```

### 6.3 Core Data Extraction with Comprehensive Joins

**Python Implementation:**
```python
def _process_benchmark_batch(idx, benchmark, audit_id, retry=3):
    """
    Process a single benchmark-date combination with comprehensive data joins.
    
    Query Architecture:
    - Main query joins 11+ tables with complex sector hierarchy logic
    - Uses SQLAlchemy aliasing for multiple joins to same table types
    - Implements COALESCE logic for sector fallbacks at SQL level
    """
    # Set up table aliases for complex joins
    C = DMIRBRSBenchmarkConstituent
    INST = DMIRBRSInstrument
    B = DWGNBenchmarkCharacteristic
    IT1, IT3, IT8, IT9 = [aliased(DMIRInstrumentIRType) for _ in range(4)]
    SECT_BB, SECT_LH, SECT_ML, SECT_JPM, SECT_MSCI, SECT_ICB = [
        aliased(DMIRBRSInstSector) for _ in range(6)
    ]
    
    # Build comprehensive query with all required fields
    qry = session.query(
        # Core benchmark and instrument data
        func.EOMONTH(literal(accounting_date)).label("datPeriodLastDay"),
        literal(accounting_date).label("Accountingdate"), 
        literal(bm_id).label("BKGNCode"),
        C.numInstId.label("InstrumentDWHID"),
        # Instrument details and identifiers
        C.strInstISINCode.label("ISINCode"),
        INST.strInstName.label("strInstName"),
        INST.numInstCouponRate.label("numInstCouponRate"),
        # Multi-hierarchy sector classifications with COALESCE
        func.coalesce(SECT_BB.strInstSectorL1, SECT_BB.strIssSector1Label).label("InstrSectorBBLevel1"),
        func.coalesce(SECT_BB.strInstSectorL2, SECT_BB.strIssSector2Label).label("InstrSectorBBLevel2"),
        func.coalesce(SECT_MSCI.strInstSectorL1, SECT_MSCI.strIssSector1Label).label("InstrSectorMSCILevel1"),
        func.coalesce(SECT_ICB.strInstSectorL1, SECT_ICB.strIssSector1Label).label("InstrSectorICBLevel1"),
        # Rating fields (set to NULL, populated later via separate logic)
        literal(None).label("strInstRtgSPStandardized"),
        literal(None).label("strInstRtgMDStandardized"),
        # Analytics data from benchmark instrument indicators
        AGG.numEffectDurationContrib,
        AGG.numMCDurationContrib,
        AGG.numESGGlbScore.label("InstrESGGlbScore"),
    ).select_from(C)\
    .outerjoin(INST, C.numInstId == INST.numInstID)\
    .outerjoin(B, B.strBnchmkCd == cast(C.numBenchFBAId, String(10)))\
    .outerjoin(IT3, (INST.numInstTypeId == IT3.numInstrTypeID) & (IT3.strReportingType == "class3"))\
    .outerjoin(SECT_BB, (INST.numInstID == SECT_BB.numInstID) & (SECT_BB.strInstSectorAgy == "BNPP_BICS"))\
    .outerjoin(SECT_MSCI, (INST.numInstID == SECT_MSCI.numInstID) & (SECT_MSCI.strInstSectorAgy == "MSCI"))\
    .outerjoin(AGG, and_(
        AGG.numBenchFBAId == bm_id,
        AGG.datPeriodLastDay == period_last_date, 
        AGG.numInstID == C.numInstId,
    ))\
    .filter(C.datMarketDate == accounting_date, C.numBenchFBAId == bm_id)
```

### 6.4 Chunked Bulk Data Retrieval

**Python Implementation:**
```python
# Fetch additional data in chunks for performance
CHUNK_SIZE = 1000

# 1. Analytics data
analytics_records = {}
for cid, chunk in enumerate(chunker(instrument_ids, CHUNK_SIZE)):
    analytics_query = session.query(
        DMIRBRSInstAnalytic.numInstID,
        DMIRBRSInstAnalytic.datInstQuotationDate,
        DMIRBRSInstAnalytic.numInstYieldToMaturity,
        DMIRBRSInstAnalytic.numInstEffDuration,
        DMIRBRSInstAnalytic.numInstModifDuration,
        DMIRBRSInstAnalytic.numInstSpreadDuration,
    ).filter(
        DMIRBRSInstAnalytic.numInstID.in_(chunk),
        DMIRBRSInstAnalytic.datInstQuotationDate == accounting_date,
    )
    for a in analytics_query.all():
        analytics_records[(a.numInstID, pd.to_datetime(a.datInstQuotationDate))] = a

# 2. Instrument ratings
ratings_records = {}
for inst_chunk in chunker(instrument_ids, CHUNK_SIZE):
    ratings_query = session.query(
        DMIRBRSInstRating.numInstID,
        DMIRBRSInstRating.strInstRtgSPStandardized,
        DMIRBRSInstRating.strInstRtgMDStandardized,
        DMIRBRSInstRating.strInstRtgFHStandardized,
        *[getattr(DMIRBRSInstRating, f'strInstRtgCustom{i}') for i in range(1, 14)]
    ).filter(
        DMIRBRSInstRating.numInstID.in_(inst_chunk),
        DMIRBRSInstRating.datInstRtgDate == period_last_date,
        DMIRBRSInstRating.strInstRtgVision == "M",
    )
    for rating in ratings_query.all():
        ratings_records[rating.numInstID] = rating

# 3. Issuer ratings for fallback
issuer_ratings = {}
if issuer_codes:
    for code_chunk in chunker(issuer_codes, CHUNK_SIZE):
        issuer_ratings_query = session.query(
            DMIRBRSIssuerRating.strInstIssuerCode,
            DMIRBRSIssuerRating.strInstRtgSPStandardized,
            *[getattr(DMIRBRSIssuerRating, f'strInstRtgCustom{i}') for i in range(1, 14)]
        ).filter(
            DMIRBRSIssuerRating.strInstIssuerCode.in_(code_chunk),
            DMIRBRSIssuerRating.datIssuerRtgDate == period_last_date,
            DMIRBRSIssuerRating.strIssuerRtgVision == "M",
        )
```

### 6.5 Derivative Processing with Multi-Level Underlying Logic

**Python Implementation:**
```python
# Identify derivative instruments requiring special processing
derivatives = [
    r for r in results
    if r.get("strInstrumentTypeIRName3") in [
        "Future on OPC", "CDS on Corporate", "CDS on Index", "CDS Tranche",
        "Forward Contracts", "Future on bond", "Future on bond index",
        "Future on stock", "Future on stock index", "Listed Option on Bond",
        "Listed Option On Index", "Listed Option on Stock",
        "Option on Stock derivatives", "OTC Option On Index", "OTC Option On Stock",
        "Warrant", "Listed Option On Future On Bond", "Listed Option On Future On Index",
        "Listed Option On Future On Stock", "OTC Option On Future On Bond",
        "OTC Option On Future On Index", "OTC Option On Future On Stock",
    ]
]

if derivatives:
    # Get underlying instruments for derivatives
    underlyings_query = session.query(
        DMIRBRSInstrument.numInstID,
        DMIRBRSInstrument.numInstUndrlygID,
        DMIRBRSInstrument.datInstMaturityDate,
        DMIRBRSInstrument.strInstIssueCountryLabel,
        DMIRBRSInstrument.strInstIssuerCountryLabel,
        DMIRBRSInstrument.strInstRiskCountryLabel,
    ).filter(DMIRBRSInstrument.numInstID.in_(instrument_ids))
    instruments = {i.numInstID: i for i in underlyings_query.all()}
    
    # Get second-level underlyings for options on futures
    second_level_ids = [i.numInstUndrlygID for i in instruments.values() if i.numInstUndrlygID]
    if second_level_ids:
        level2_query = session.query(
            DMIRBRSInstrument.numInstID,
            DMIRBRSInstrument.numInstUndrlygID, 
            DMIRBRSInstrument.datInstMaturityDate,
            DMIRBRSInstrument.strInstIssueCountryLabel,
            DMIRBRSInstrument.strInstIssuerCountryLabel,
            DMIRBRSInstrument.strInstRiskCountryLabel,
        ).filter(DMIRBRSInstrument.numInstID.in_(second_level_ids))
        level2_instruments = {i.numInstID: i for i in level2_query.all()}

        # Apply derivative-specific overrides
        for record in derivatives:
            instr = instruments.get(record["InstrumentDWHID"])
            if instr and instr.numInstUndrlygID:
                # Special maturity date handling for futures on bonds
                if record["strInstrumentTypeIRName3"] == "Future on bond":
                    underlying = instruments.get(instr.numInstUndrlygID)
                    if underlying:
                        record["datInstMaturityDate"] = underlying.datInstMaturityDate
                
                # Multi-level override for options on futures on bonds        
                elif record["strInstrumentTypeIRName3"] == "Listed Option On Future On Bond":
                    underlying = instruments.get(instr.numInstUndrlygID)
                    if underlying and underlying.numInstUndrlygID:
                        underlying2 = level2_instruments.get(underlying.numInstUndrlygID)
                        if underlying2:
                            record["datInstMaturityDate"] = underlying2.datInstMaturityDate
```

### 6.6 Complex Rating Fallback Logic

**Python Implementation:**
```python
# Apply derivative-specific rating logic matching SQL UPDATE statements exactly
for record in results:
    # First-level derivative rating logic
    if record.get("strInstrumentTypeIRName3") in {
        'CDS on Corporate', 'Future on bond', 'Listed Option on Bond', 'CDS on Index'
    }:
        instr = instruments.get(record["InstrumentDWHID"])
        if instr and instr.numInstUndrlygID:
            # Get underlying instrument and issuer ratings
            ul_inst_rating = ratings_records.get(instr.numInstUndrlygID)
            ul_issuer_code = instruments.get(instr.numInstUndrlygID)
            ul_issuer_rating = issuer_ratings.get(ul_issuer_code.strInstIssuerCode) if ul_issuer_code else None
            
            # Apply COALESCE logic: current -> instrument -> issuer  
            for field in ["strInstRtgSPStandardized", "strInstRtgMDStandardized", 
                         "strInstRtgFHStandardized"] + [f"strInstRtgCustom{i}" for i in range(1, 14)]:
                current_val = record.get(field)
                if not current_val:
                    # Try underlying instrument rating
                    if ul_inst_rating:
                        underlying_val = getattr(ul_inst_rating, field, None)
                        if underlying_val:
                            record[field] = underlying_val
                            continue
                    # Try underlying issuer rating
                    if ul_issuer_rating:
                        issuer_field = field.replace("strInstRtg", "strIssuerRtg") if "Standardized" in field else field.replace("strInstRtg", "strIssuerRtg")
                        issuer_val = getattr(ul_issuer_rating, issuer_field, None)
                        if issuer_val:
                            record[field] = issuer_val
    
    # Second-level derivative rating logic for complex derivatives
    elif record.get("strInstrumentTypeIRName3") in {
        "Listed Option On Future On Bond", "OTC Option On Future On Bond", # etc.
    }:
        instr = instruments.get(record["InstrumentDWHID"])
        if instr and instr.numInstUndrlygID:
            ul1 = instruments.get(instr.numInstUndrlygID)
            if ul1 and ul1.numInstUndrlygID:
                ul2 = level2_instruments.get(ul1.numInstUndrlygID)
                
                # Extended COALESCE: current -> ul1_inst -> ul1_issuer -> ul2_inst -> ul2_issuer
                ul1_inst_rating = ratings_records.get(ul1.numInstID)
                ul1_issuer_rating = issuer_ratings.get(ul1.strInstIssuerCode)
                ul2_inst_rating = ratings_records.get(ul2.numInstID) if ul2 else None
                ul2_issuer_rating = issuer_ratings.get(ul2.strInstIssuerCode) if ul2 else None
                
                for field in rating_fields:
                    current_val = record.get(field)
                    if not current_val:
                        # 5-level fallback chain
                        for rating_source in [ul1_inst_rating, ul1_issuer_rating, ul2_inst_rating, ul2_issuer_rating]:
                            if rating_source:
                                val = getattr(rating_source, field, None)
                                if val:
                                    record[field] = val
                                    break
```

### 6.7 Sector Classification for Cash and Derivatives

**Python Implementation:**
```python
# Special sector classification logic for cash and derivatives
for record in results:
    upper_name_9 = (record.get("strInstrumentTypeIRName9", "") or "").upper()
    
    if upper_name_9 == "CASH" or "DERIVATIVES" in upper_name_9 or upper_name_9 == "IRS":
        # Check if instrument should get special classification
        upper_name_3 = (record.get("strInstrumentTypeIRName3", "") or "").upper()
        conditions_met = (
            record.get("strInstrumentTypeIRName3")
            and "BOND" not in upper_name_3
            and "STOCK" not in upper_name_3  
            and "WARRANT" not in upper_name_3
            and "CDS" not in upper_name_3
            and "CORPORATE" not in upper_name_3
        )
        
        if conditions_met:
            sector_value = "Cash" if upper_name_9 == "CASH" else "Derivatives"
            # Update all sector hierarchy levels
            record.update({
                "InstrSectorBBLevel1": sector_value,
                "InstrSectorBBLevel2": sector_value, 
                "InstrSectorBBLevel3": sector_value,
                "InstrSectorLHLevel1": sector_value,
                "InstrSectorLHLevel2": sector_value,
                "InstrSectorLHLevel3": sector_value,
                "InstrSectorMSCILevel1": sector_value,
                "InstrSectorMSCILevel2": sector_value,
                "InstrSectorMSCILevel3": sector_value,
                "InstrSectorICBLevel1": sector_value,
                "InstrSectorICBLevel2": sector_value,
                "InstrSectorICBLevel3": sector_value,
            })
```

### 6.8 Final Data Processing and Bulk Insert

**Python Implementation:**
```python
# Final data cleanup and type conversion
for record in results:
    # Convert decimals to floats
    for k, v in record.items():
        if isinstance(v, decimal.Decimal):
            record[k] = float(v)
        # Convert empty strings and NaN to None
        if (isinstance(v, str) and v.strip() == "") or pd.isna(v):
            record[k] = None

# Bulk insert using SQLAlchemy
session.bulk_insert_mappings(DMIRAPIBenchHolding, results)
session.commit()

# Clean up old records (36 months retention)
old_date = datetime.now() - relativedelta(months=36)
result = session.query(DMIRAPIBenchHolding)\
    .filter(DMIRAPIBenchHolding.Accountingdate < old_date)\
    .delete(synchronize_session=False)
```
