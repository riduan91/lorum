# Benchmark Instrument Indicators Migration Guide

## Overview
This document explains the migration from the SQL stored procedure `stpDMIRBenchmarkAggregate_BRS` (part 2) to the Python workflow/procedure pair: `workflow_bench_instr_indicators.py` and `procedure_bench_instr_indicators.py`.

## SQL Source
- **Stored Procedure**: `stpDMIRBenchmarkAggregate_BRS` (part 2)
- **SQL File**: `dags/sql/stpDMIRBenchmarkAggregate_BRS.sql`
- **Lines Covered**: 400-2000 (instrument indicator computation with BKGN_1 through BKGN_7 stages)
- **Purpose**: Multi-stage instrument-level indicator computation including analytics, ESG data, risk metrics, and rating analysis

## Python Implementation

### Workflow File
- **File**: `dags/benchmark_aggregates_holdings/workflow_bench_instr_indicators.py`
- **Purpose**: Airflow task orchestration for instrument indicator computation

### Procedure File
- **File**: `dags/benchmark_aggregates_holdings/procedure_bench_instr_indicators.py`
- **Purpose**: Core business logic for multi-stage instrument indicator processing

---

## 1. Tables Used as Inputs

| Table Name                              | Description                                                                                                          |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **DMIR.tblDMIRBenchScopeAG**           | Benchmark scope: defines which benchmarks need instrument indicator processing for which periods                    |
| **DMIR.tblDMIRBRSBenchmarkConstituent** | Benchmark constituents: instrument positions within benchmarks with weights, quantities, and market values         |
| **DMIR.tblDMIRBRSInstrument**          | Instrument master: instrument metadata including types, ISINs, sectors, and issuer information                     |
| **DMIR.tblDMIRBRSInstAnalytic**        | Instrument analytics: duration, convexity, yield, and other risk metrics for fixed income instruments              |
| **DMIR.tblDMIRBRSSector**              | Sector classifications: multiple sector hierarchies (Bloomberg, MSCI, internal) for instrument categorization      |
| **DMIR.tblDMIRBRSIssuer**              | Issuer information: issuer details including ratings, sectors, and country assignments                             |
| **DMIR.tblDMIRBRSCountry**             | Country master: country codes, names, and regional classifications                                                  |
| **DMIR.tblDMIRBRSCurrencyQuote**       | Currency rates: daily exchange rates for multi-currency calculations                                               |
| **ESG Tables**                         | ESG scores, CO2 data, controversy scores: sustainability and environmental impact metrics                          |
| **Rating Tables**                      | Credit ratings from multiple agencies: S&P, Moody's, Fitch ratings for instruments and issuers                   |

---

## 2. Target Tables

- **DMIR.tblDMIRBRSBenchInstrIndicators**  
  *In Python:* populated via multi-stage processing through BKGN_1 to BKGN_7 pipeline with complete instrument indicators.  
  *Description:* Final repository for instrument-level indicators including analytics, ESG scores, ratings, sector classifications, and risk metrics.

---

## 3. Temporary (Staging) Tables / DataFrames

| Staging Table (SQL)                    | Purpose / Description                                                                                                | Equivalent pandas DataFrame(s)                      |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| **#BKGNScope**                        | Initial scope: benchmark/instrument combinations requiring indicator computation                                      | `df_scope` in `compute_instr_indicators_scope()`    |
| **#BKGN_1**                           | Stage 1: Basic constituent data with instrument mappings and initial position information                           | `df_bkgn1` in `compute_instr_indicators_bkgn_1()`   |
| **#BKGN_2**                           | Stage 2: Enhanced with instrument analytics (duration, convexity, yield, risk metrics)                             | `df_bkgn2` in `compute_instr_indicators_bkgn_2()`   |
| **#BKGN_3**                           | Stage 3: Added contribution calculations (duration contribution, yield contribution)                                | `df_bkgn3` in `compute_instr_indicators_bkgn_3()`   |
| **#BKGN_4**                           | Stage 4: Sector classifications from multiple hierarchies (Bloomberg, MSCI, internal sectors)                      | `df_bkgn4` in `compute_instr_indicators_bkgn_4()`   |
| **#BKGN_5**                           | Stage 5: Issuer information including ratings, issuer sectors, and country assignments                              | `df_bkgn5` in `compute_instr_indicators_bkgn_5()`   |
| **#BKGN_6**                           | Stage 6: ESG data integration (ESG scores, CO2 intensity, controversy data, sustainability metrics)                | `df_bkgn6` in `compute_instr_indicators_bkgn_6()`   |
| **#BKGN_7**                           | Stage 7: Final processing with currency conversion, rating standardization, and data validation                     | `df_bkgn7` in `compute_instr_indicators_bkgn_7()`   |
| *analytics staging*                   | Instrument analytics lookup and merging for duration, convexity, and yield metrics                                  | `df_analytics` in analytics processing functions    |
| *esg staging*                         | ESG data consolidation from multiple ESG data providers and scoring systems                                         | `df_esg_combined` in ESG integration functions      |
| *rating staging*                      | Credit rating lookup and standardization from multiple rating agencies                                              | `df_ratings_consolidated` in rating processing       |
| *sector staging*                      | Multi-level sector classification merging and hierarchy resolution                                                   | `df_sectors_merged` in sector classification logic  |

---

## 4. Task Breakdown for the Airflow DAG

| Task Name (`@task`)                              | Description                                                                                                                                                                                                                      | Inputs / Outputs                                                    | Parallelizable?                                    |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- | -------------------------------------------------- |
| **task__start_group**                           | Initialize instrument indicator processing: log workflow start and validate prerequisite scope data                                                                                                                             | **In:** audit_id from params <br>**Out:** initialization status    | ❌ (workflow initialization)                       |
| **task__compute_instr_indicators_scope**        | Scope identification: identify benchmark/instrument combinations requiring indicator computation based on benchmark scope                                                                                                        | **In:** benchmark scope data <br>**Out:** `df_scope`               | ❌ (defines processing universe for all stages)    |
| **task__compute_instr_indicators_bkgn_1**       | **Stage 1**: Basic constituent data processing - extract constituent positions, weights, quantities, and basic instrument information                                                                                            | **In:** `df_scope` <br>**Out:** `df_bkgn1`                         | ✔️ (can process benchmark chunks in parallel)     |
| **task__compute_instr_indicators_bkgn_2**       | **Stage 2**: Analytics integration - merge instrument analytics including duration, convexity, yield, spread, and other risk metrics                                                                                           | **In:** `df_bkgn1` <br>**Out:** `df_bkgn2`                         | ✔️ (analytics lookups can be parallelized)        |
| **task__compute_instr_indicators_bkgn_3**       | **Stage 3**: Contribution calculations - compute duration contribution, yield contribution, spread contribution based on position weights                                                                                       | **In:** `df_bkgn2` <br>**Out:** `df_bkgn3`                         | ✔️ (mathematical calculations can be vectorized)   |
| **task__compute_instr_indicators_bkgn_4**       | **Stage 4**: Sector classification - add multi-level sector hierarchies from Bloomberg, MSCI, and internal classification systems                                                                                              | **In:** `df_bkgn3` <br>**Out:** `df_bkgn4`                         | ✔️ (sector lookups can be parallel by hierarchy)  |
| **task__compute_instr_indicators_bkgn_5**       | **Stage 5**: Issuer information - integrate issuer data including issuer ratings, issuer sectors, country assignments, and regional classifications                                                                           | **In:** `df_bkgn4` <br>**Out:** `df_bkgn5`                         | ✔️ (issuer lookups can be chunked and parallel)   |
| **task__compute_instr_indicators_bkgn_6**       | **Stage 6**: ESG integration - merge ESG scores, CO2 intensity, controversy data, engagement scores, and sustainability metrics from multiple providers                                                                       | **In:** `df_bkgn5` <br>**Out:** `df_bkgn6`                         | ✔️ (ESG data sources can be processed in parallel) |
| **task__compute_instr_indicators_bkgn_7**       | **Stage 7**: Final processing - currency conversion, rating standardization, data validation, and preparation for final storage                                                                                                | **In:** `df_bkgn6` <br>**Out:** `df_bkgn7` (final indicators)      | ✔️ (final transformations can be parallelized)    |
| **task__insert_final_instrument_indicators**   | Data persistence: bulk insert final instrument indicators into target table with audit trails and data quality checks                                                                                                          | **In:** `df_bkgn7` <br>**Out:** insertion counts and status        | ❌ (final insertion must be atomic)               |
| **task__cleanup_and_validate**                 | Post-processing: cleanup temporary data, validate final results, and generate processing metrics                                                                                                                                | **In:** processing status <br>**Out:** validation results          | ❌ (final validation and cleanup)                  |
| **task__end_group**                             | Workflow completion: log successful completion and processing statistics                                                                                                                                                        | **In:** final status <br>**Out:** completion metrics               | ❌ (workflow finalization)                         |

> **Multi-Stage Pipeline Architecture**  
> The 7-stage processing pipeline (BKGN_1 through BKGN_7) ensures that each stage builds upon the previous one, adding specific types of information systematically. This approach enables:
> - **Independent Testing**: Each stage can be tested in isolation
> - **Parallel Processing**: Multiple benchmarks can be processed through the same stage simultaneously  
> - **Error Recovery**: Failed stages can be restarted without reprocessing earlier stages
> - **Performance Optimization**: Resource-intensive stages can be optimized independently

> **ESG Integration Workflow**  
> Stage 6 integrates with a separate ESG processing workflow that includes:
> - ESG score calculation and standardization
> - CO2 intensity analysis and carbon footprint metrics
> - Controversy score assessment and risk evaluation
> - Engagement and stewardship scoring
> - Sustainability classification and green bond identification

> **Concurrency Notes**  
> - **Analytics Processing**: Duration, convexity, and yield calculations can be vectorized and parallelized
> - **Sector Classification**: Multiple sector hierarchies can be processed concurrently
> - **ESG Data Integration**: Different ESG data sources can be processed in parallel then consolidated
> - **Rating Standardization**: Credit ratings from different agencies can be processed simultaneously
> - **Currency Conversion**: Multi-currency calculations can be parallelized by currency groups

---

## 5. High‑Level DAG Structure Diagram

```text
      ┌─────────────────────────────────────────┐
      │ task__start_group                       │
      │ (initialize processing)                 │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_instr_indicators_scope    │
      │ (identify benchmark/instrument pairs)   │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_instr_indicators_bkgn_1   │
      │ Stage 1: Basic Constituent Data         │
      │ • Position weights & quantities         │
      │ • Basic instrument information          │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_instr_indicators_bkgn_2   │
      │ Stage 2: Analytics Integration          │
      │ • Duration, convexity, yield            │
      │ • Risk metrics and spreads              │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_instr_indicators_bkgn_3   │
      │ Stage 3: Contribution Calculations     │
      │ • Duration contribution                 │
      │ • Yield contribution                    │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_instr_indicators_bkgn_4   │
      │ Stage 4: Sector Classifications        │
      │ • Bloomberg sectors                     │
      │ • MSCI sectors                          │
      │ • Internal classifications              │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_instr_indicators_bkgn_5   │
      │ Stage 5: Issuer Information             │
      │ • Issuer ratings                        │
      │ • Country assignments                   │
      │ • Regional classifications              │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_instr_indicators_bkgn_6   │
      │ Stage 6: ESG Integration                │
      │ • ESG scores & ratings                  │
      │ • CO2 intensity data                    │
      │ • Controversy & engagement scores       │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_instr_indicators_bkgn_7   │
      │ Stage 7: Final Processing               │
      │ • Currency conversion                   │
      │ • Rating standardization                │
      │ • Data validation                       │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__insert_final_instrument_indicators│
      │ (bulk insert with audit trails)        │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__cleanup_and_validate              │
      │ (cleanup & validation)                  │
      └─────────────────────────────────────────┘
---

## 6. Functional Mapping Details

### 1. Scope Identification and Initialization
**SQL Section**: Lines 400-450 (scope definition for instrument processing)  
**Python Implementation**: `compute_instr_indicators_scope()`

**SQL Logic**:
```sql
-- Create scope for instrument indicators
SELECT DISTINCT 
    s.numBenchMarkId,
    s.datPeriodLastDay,
    s.strPeriodTypeFlag,
    c.numInstId,
    c.datMarketDate
INTO #BKGNScope
FROM DMIR.tblDMIRBenchScopeAG s
INNER JOIN DMIR.tblDMIRBRSBenchmarkConstituent c
    ON c.numBenchFBAId = s.numBenchMarkId
    AND c.datMarketDate <= s.datPeriodLastDay
WHERE s.numAuditId = @numAuditId
```

**Python Equivalent**:
```python
def compute_instr_indicators_scope(audit_id):
    """
    Identify benchmark/instrument combinations requiring indicator computation.
    Equivalent to SQL scope identification logic.
    """
    session = get_session()
    try:
        scope_query = session.query(
            DMIRBenchScopeAG.numBenchMarkId,
            DMIRBenchScopeAG.datPeriodLastDay,
            DMIRBenchScopeAG.strPeriodTypeFlag,
            DMIRBRSBenchmarkConstituent.numInstId,
            DMIRBRSBenchmarkConstituent.datMarketDate
        ).join(
            DMIRBRSBenchmarkConstituent,
            and_(
                DMIRBRSBenchmarkConstituent.numBenchFBAId == DMIRBenchScopeAG.numBenchMarkId,
                DMIRBRSBenchmarkConstituent.datMarketDate <= DMIRBenchScopeAG.datPeriodLastDay
            )
        ).filter(
            DMIRBenchScopeAG.numAuditId == audit_id
        ).distinct()
        
        return get_all_as_df(scope_query)
    finally:
        session.close()
```

### 2. Stage 1: Basic Constituent Data Processing (BKGN_1)
**SQL Section**: Lines 450-600 (constituent data extraction with basic calculations)  
**Python Implementation**: `compute_instr_indicators_bkgn_1()`

**SQL Logic**:
```sql
SELECT 
    c.numBenchFBAId,
    c.numInstId,
    c.datMarketDate,
    c.numInstWeight,
    c.numInstQty,
    c.numInstMarketValue,
    c.numInstLocalCurPrice,
    i.strInstISINCode,
    i.strInstInternalCode
INTO #BKGN_1
FROM #BKGNScope s
INNER JOIN DMIR.tblDMIRBRSBenchmarkConstituent c
    ON c.numBenchFBAId = s.numBenchMarkId
    AND c.numInstId = s.numInstId
    AND c.datMarketDate = s.datMarketDate
LEFT JOIN DMIR.tblDMIRBRSInstrument i
    ON i.numInstID = c.numInstId
```

**Python Equivalent**:
```python
def compute_instr_indicators_bkgn_1(df_scope):
    """
    Stage 1: Extract basic constituent data with instrument mappings.
    Equivalent to SQL BKGN_1 processing.
    """
    session = get_session()
    try:
        # Process scope in chunks to manage memory
        chunk_size = 10000
        df_chunks = []
        
        for chunk in [df_scope[i:i+chunk_size] for i in range(0, len(df_scope), chunk_size)]:
            # Build query for current chunk
            bkgn1_query = session.query(
                DMIRBRSBenchmarkConstituent.numBenchFBAId,
                DMIRBRSBenchmarkConstituent.numInstId,
                DMIRBRSBenchmarkConstituent.datMarketDate,
                DMIRBRSBenchmarkConstituent.numInstWeight,
                DMIRBRSBenchmarkConstituent.numInstQty,
                DMIRBRSBenchmarkConstituent.numInstMarketValue,
                DMIRBRSBenchmarkConstituent.numInstLocalCurPrice,
                DMIRBRSInstrument.strInstISINCode,
                DMIRBRSInstrument.strInstInternalCode
            ).outerjoin(
                DMIRBRSInstrument,
                DMIRBRSInstrument.numInstID == DMIRBRSBenchmarkConstituent.numInstId
            ).filter(
                # Apply scope filter based on chunk data
                tuple_(
                    DMIRBRSBenchmarkConstituent.numBenchFBAId,
                    DMIRBRSBenchmarkConstituent.numInstId,
                    DMIRBRSBenchmarkConstituent.datMarketDate
                ).in_(chunk[['numBenchMarkId', 'numInstId', 'datMarketDate']].values.tolist())
            )
            
            df_chunks.append(get_all_as_df(bkgn1_query))
        
        return pd.concat(df_chunks, ignore_index=True)
    finally:
        session.close()
```

### 3. Stage 2: Analytics Integration (BKGN_2)
**SQL Section**: Lines 600-800 (instrument analytics merging)  
**Python Implementation**: `compute_instr_indicators_bkgn_2()`

**SQL Logic**:
```sql
SELECT 
    b1.*,
    a.numEffectDuration,
    a.numConvexity,
    a.numYTM,
    a.numSpread,
    a.numDTS,
    a.datAnalyticsDate
INTO #BKGN_2
FROM #BKGN_1 b1
LEFT JOIN DMIR.tblDMIRBRSInstAnalytic a
    ON a.numInstID = b1.numInstId
    AND a.datAnalyticsDate = (
        SELECT MAX(datAnalyticsDate)
        FROM DMIR.tblDMIRBRSInstAnalytic a2
        WHERE a2.numInstID = b1.numInstId
        AND a2.datAnalyticsDate <= b1.datMarketDate
    )
```

**Python Equivalent**:
```python
def compute_instr_indicators_bkgn_2(df_bkgn1):
    """
    Stage 2: Add instrument analytics data (duration, convexity, yield).
    Equivalent to SQL BKGN_2 processing with latest analytics lookup.
    """
    session = get_session()
    try:
        # Get unique instruments from BKGN_1
        unique_instruments = df_bkgn1['numInstId'].unique().tolist()
        
        # Get latest analytics for each instrument
        analytics_dict = {}
        for inst_chunk in [unique_instruments[i:i+1000] for i in range(0, len(unique_instruments), 1000)]:
            analytics_query = session.query(
                DMIRBRSInstAnalytic.numInstID,
                DMIRBRSInstAnalytic.numEffectDuration,
                DMIRBRSInstAnalytic.numConvexity,
                DMIRBRSInstAnalytic.numYTM,
                DMIRBRSInstAnalytic.numSpread,
                DMIRBRSInstAnalytic.numDTS,
                DMIRBRSInstAnalytic.datAnalyticsDate
            ).filter(
                DMIRBRSInstAnalytic.numInstID.in_(inst_chunk)
            ).all()
            
            # Process analytics to get latest for each instrument
            for analytics in analytics_query:
                inst_id = analytics.numInstID
                if inst_id not in analytics_dict or analytics.datAnalyticsDate > analytics_dict[inst_id]['datAnalyticsDate']:
                    analytics_dict[inst_id] = {
                        'numEffectDuration': analytics.numEffectDuration,
                        'numConvexity': analytics.numConvexity,
                        'numYTM': analytics.numYTM,
                        'numSpread': analytics.numSpread,
                        'numDTS': analytics.numDTS,
                        'datAnalyticsDate': analytics.datAnalyticsDate
                    }
        
        # Merge analytics back to BKGN_1 data
        df_analytics = pd.DataFrame.from_dict(analytics_dict, orient='index')
        df_analytics.index.name = 'numInstId'
        df_analytics = df_analytics.reset_index()
        
        df_bkgn2 = df_bkgn1.merge(df_analytics, on='numInstId', how='left')
        return df_bkgn2
    finally:
        session.close()
```

### 4. Stage 3: Contribution Calculations (BKGN_3)
**SQL Section**: Lines 800-950 (mathematical contribution calculations)  
**Python Implementation**: `compute_instr_indicators_bkgn_3()`

**SQL Logic**:
```sql
SELECT 
    b2.*,
    CASE WHEN numBenchWeight > 0 
         THEN (numInstWeight / numBenchWeight) * numEffectDuration 
         ELSE 0 
    END AS numEffectDurationContrib,
    CASE WHEN numBenchWeight > 0 
         THEN (numInstWeight / numBenchWeight) * numYTM 
         ELSE 0 
    END AS numYTMContrib,
    CASE WHEN numBenchWeight > 0 
         THEN (numInstWeight / numBenchWeight) * numSpread 
         ELSE 0 
    END AS numSpreadContrib
INTO #BKGN_3
FROM #BKGN_2 b2
LEFT JOIN (
    SELECT numBenchFBAId, SUM(numInstWeight) AS numBenchWeight
    FROM #BKGN_2 
    GROUP BY numBenchFBAId
) bw ON bw.numBenchFBAId = b2.numBenchFBAId
```

**Python Equivalent**:
```python
def compute_instr_indicators_bkgn_3(df_bkgn2):
    """
    Stage 3: Calculate contribution metrics based on position weights.
    Equivalent to SQL BKGN_3 mathematical calculations.
    """
    # Calculate benchmark-level totals
    benchmark_weights = df_bkgn2.groupby('numBenchFBAId')['numInstWeight'].sum().reset_index()
    benchmark_weights.rename(columns={'numInstWeight': 'numBenchWeight'}, inplace=True)
    
    # Merge benchmark weights back
    df_with_bench_weights = df_bkgn2.merge(benchmark_weights, on='numBenchFBAId', how='left')
    
    # Calculate contributions
    df_bkgn3 = df_with_bench_weights.copy()
    
    # Duration contribution
    df_bkgn3['numEffectDurationContrib'] = np.where(
        df_bkgn3['numBenchWeight'] > 0,
        (df_bkgn3['numInstWeight'] / df_bkgn3['numBenchWeight']) * df_bkgn3['numEffectDuration'],
        0
    )
    
    # Yield contribution
    df_bkgn3['numYTMContrib'] = np.where(
        df_bkgn3['numBenchWeight'] > 0,
        (df_bkgn3['numInstWeight'] / df_bkgn3['numBenchWeight']) * df_bkgn3['numYTM'],
        0
    )
    
    # Spread contribution
    df_bkgn3['numSpreadContrib'] = np.where(
        df_bkgn3['numBenchWeight'] > 0,
        (df_bkgn3['numInstWeight'] / df_bkgn3['numBenchWeight']) * df_bkgn3['numSpread'],
        0
    )
    
    return df_bkgn3
```

### 5. Stage 4: Sector Classification (BKGN_4)
**SQL Section**: Lines 950-1200 (multi-level sector hierarchy integration)  
**Python Implementation**: `compute_instr_indicators_bkgn_4()`

**SQL Logic**:
```sql
SELECT 
    b3.*,
    s1.strSectorL1 AS strBloombergSectorL1,
    s1.strSectorL2 AS strBloombergSectorL2,
    s2.strMSCISectorL1,
    s2.strMSCISectorL2,
    s3.strInternalSectorL1
INTO #BKGN_4
FROM #BKGN_3 b3
LEFT JOIN DMIR.tblDMIRBRSSector s1
    ON s1.numInstID = b3.numInstId
    AND s1.strSectorType = 'BLOOMBERG'
LEFT JOIN DMIR.tblDMIRBRSSector s2
    ON s2.numInstID = b3.numInstId
    AND s2.strSectorType = 'MSCI'
LEFT JOIN DMIR.tblDMIRBRSSector s3
    ON s3.numInstID = b3.numInstId
    AND s3.strSectorType = 'INTERNAL'
```

**Python Equivalent**:
```python
def compute_instr_indicators_bkgn_4(df_bkgn3):
    """
    Stage 4: Add sector classifications from multiple hierarchies.
    Equivalent to SQL BKGN_4 multi-sector processing.
    """
    session = get_session()
    try:
        unique_instruments = df_bkgn3['numInstId'].unique().tolist()
        
        # Get all sector data for instruments
        sector_data = {}
        for inst_chunk in [unique_instruments[i:i+1000] for i in range(0, len(unique_instruments), 1000)]:
            sector_query = session.query(
                DMIRBRSSector.numInstID,
                DMIRBRSSector.strSectorType,
                DMIRBRSSector.strSectorL1,
                DMIRBRSSector.strSectorL2,
                DMIRBRSSector.strSectorL3
            ).filter(
                DMIRBRSSector.numInstID.in_(inst_chunk),
                DMIRBRSSector.strSectorType.in_(['BLOOMBERG', 'MSCI', 'INTERNAL'])
            ).all()
            
            for sector in sector_query:
                if sector.numInstID not in sector_data:
                    sector_data[sector.numInstID] = {}
                
                sector_prefix = f"str{sector.strSectorType.title()}"
                sector_data[sector.numInstID].update({
                    f"{sector_prefix}SectorL1": sector.strSectorL1,
                    f"{sector_prefix}SectorL2": sector.strSectorL2,
                    f"{sector_prefix}SectorL3": sector.strSectorL3
                })
        
        # Convert to DataFrame and merge
        df_sectors = pd.DataFrame.from_dict(sector_data, orient='index')
        df_sectors.index.name = 'numInstId'
        df_sectors = df_sectors.reset_index()
        
        df_bkgn4 = df_bkgn3.merge(df_sectors, on='numInstId', how='left')
        return df_bkgn4
    finally:
        session.close()
```

### 6. Stage 6: ESG Integration (BKGN_6)
**SQL Section**: Lines 1400-1600 (ESG data integration from multiple sources)  
**Python Implementation**: `compute_instr_indicators_bkgn_6()` with ESG workflow integration

**SQL Logic**:
```sql
SELECT 
    b5.*,
    esg.numESGScore,
    esg.strESGRating,
    co2.numCO2Intensity,
    cont.numControversyScore,
    eng.numEngagementScore
INTO #BKGN_6
FROM #BKGN_5 b5
LEFT JOIN DMIR.tblDMIRESGScores esg
    ON esg.numInstID = b5.numInstId
LEFT JOIN DMIR.tblDMIRCO2Intensity co2
    ON co2.numInstID = b5.numInstId
LEFT JOIN DMIR.tblDMIRControversyScores cont
    ON cont.numInstID = b5.numInstId
LEFT JOIN DMIR.tblDMIREngagementScores eng
    ON eng.numInstID = b5.numInstId
```

**Python Equivalent**:
```python
def compute_instr_indicators_bkgn_6(df_bkgn5):
    """
    Stage 6: Integrate ESG data from multiple sources.
    Equivalent to SQL BKGN_6 with ESG workflow integration.
    """
    # ESG integration leverages separate ESG processing workflow
    # This function consolidates ESG data from various sources
    
    session = get_session()
    try:
        unique_instruments = df_bkgn5['numInstId'].unique().tolist()
        
        # Parallel ESG data collection
        esg_data_futures = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            esg_data_futures.append(
                executor.submit(get_esg_scores, unique_instruments, session)
            )
            esg_data_futures.append(
                executor.submit(get_co2_intensity, unique_instruments, session)
            )
            esg_data_futures.append(
                executor.submit(get_controversy_scores, unique_instruments, session)
            )
            esg_data_futures.append(
                executor.submit(get_engagement_scores, unique_instruments, session)
            )
        
        # Collect ESG data results
        df_esg_scores = esg_data_futures[0].result()
        df_co2_data = esg_data_futures[1].result()
        df_controversy = esg_data_futures[2].result()
        df_engagement = esg_data_futures[3].result()
        
        # Sequential merging of ESG data
        df_bkgn6 = df_bkgn5.copy()
        df_bkgn6 = df_bkgn6.merge(df_esg_scores, on='numInstId', how='left')
        df_bkgn6 = df_bkgn6.merge(df_co2_data, on='numInstId', how='left')
        df_bkgn6 = df_bkgn6.merge(df_controversy, on='numInstId', how='left')
        df_bkgn6 = df_bkgn6.merge(df_engagement, on='numInstId', how='left')
        
        return df_bkgn6
    finally:
        session.close()
```

### 7. Stage 5: Issuer Information (BKGN_5)
**SQL Section**: Lines 1200-1400 (issuer data integration with issuer ratings and country assignments)  
**Python Implementation**: `compute_instr_indicators_bkgn_5()`

**SQL Logic**:
```sql
SELECT 
    b4.*,
    iss.strInstIssuerCode,
    iss.strIssuerName,
    iss.strIssuerCountryDomicile,
    iss.strIssuerSector,
    isr.strIssuerRtgSPStandardized,
    isr.strIssuerRtgMDStandardized,
    isr.strIssuerRtgFHStandardized,
    c.strCountryName,
    c.strRegion
INTO #BKGN_5
FROM #BKGN_4 b4
LEFT JOIN DMIR.tblDMIRBRSInstrument inst
    ON inst.numInstID = b4.numInstId
LEFT JOIN DMIR.tblDMIRBRSIssuer iss
    ON iss.strInstIssuerCode = inst.strInstIssuerCode
LEFT JOIN DMIR.tblDMIRBRSIssuerRating isr
    ON isr.strInstIssuerCode = iss.strInstIssuerCode
    AND isr.datIssuerRtgDate = b4.datMarketDate
LEFT JOIN DMIR.tblDMIRBRSCountry c
    ON c.strCountryISOCode = iss.strIssuerCountryDomicile
```

**Python Equivalent**:
```python
def compute_instr_indicators_bkgn_5(df_bkgn4):
    """
    Stage 5: Add issuer information including ratings and country data.
    Equivalent to SQL BKGN_5 processing with issuer data integration.
    """
    session = get_session()
    try:
        unique_instruments = df_bkgn4['numInstId'].unique().tolist()
        
        # Get issuer information for instruments
        issuer_data = {}
        for inst_chunk in [unique_instruments[i:i+1000] for i in range(0, len(unique_instruments), 1000)]:
            issuer_query = session.query(
                DMIRBRSInstrument.numInstID,
                DMIRBRSInstrument.strInstIssuerCode,
                DMIRBRSIssuer.strIssuerName,
                DMIRBRSIssuer.strIssuerCountryDomicile,
                DMIRBRSIssuer.strIssuerSector,
                DMIRBRSIssuerRating.strIssuerRtgSPStandardized,
                DMIRBRSIssuerRating.strIssuerRtgMDStandardized,
                DMIRBRSIssuerRating.strIssuerRtgFHStandardized,
                DMIRBRSCountry.strCountryName,
                DMIRBRSCountry.strRegion
            ).outerjoin(
                DMIRBRSIssuer,
                DMIRBRSIssuer.strInstIssuerCode == DMIRBRSInstrument.strInstIssuerCode
            ).outerjoin(
                DMIRBRSIssuerRating,
                and_(
                    DMIRBRSIssuerRating.strInstIssuerCode == DMIRBRSIssuer.strInstIssuerCode,
                    DMIRBRSIssuerRating.datIssuerRtgDate == df_bkgn4['datMarketDate'].iloc[0]
                )
            ).outerjoin(
                DMIRBRSCountry,
                DMIRBRSCountry.strCountryISOCode == DMIRBRSIssuer.strIssuerCountryDomicile
            ).filter(
                DMIRBRSInstrument.numInstID.in_(inst_chunk)
            ).all()
            
            for issuer in issuer_query:
                issuer_data[issuer.numInstID] = {
                    'strInstIssuerCode': issuer.strInstIssuerCode,
                    'strIssuerName': issuer.strIssuerName,
                    'strIssuerCountryDomicile': issuer.strIssuerCountryDomicile,
                    'strIssuerSector': issuer.strIssuerSector,
                    'strIssuerRtgSPStandardized': issuer.strIssuerRtgSPStandardized,
                    'strIssuerRtgMDStandardized': issuer.strIssuerRtgMDStandardized,
                    'strIssuerRtgFHStandardized': issuer.strIssuerRtgFHStandardized,
                    'strCountryName': issuer.strCountryName,
                    'strRegion': issuer.strRegion
                }
        
        # Convert to DataFrame and merge
        df_issuer = pd.DataFrame.from_dict(issuer_data, orient='index')
        df_issuer.index.name = 'numInstId'
        df_issuer = df_issuer.reset_index()
        
        df_bkgn5 = df_bkgn4.merge(df_issuer, on='numInstId', how='left')
        return df_bkgn5
    finally:
        session.close()
```

### 8. Stage 7: Final Processing and Rating Integration (BKGN_7)
**SQL Section**: Lines 850-1100 (rating integration with ESG data and final data consolidation)  
**Python Implementation**: `compute_instr_indicators_bkgn_7()`

**SQL Logic**:
```sql
-- Stage 7tmp: Rating integration and contribution calculations
SELECT 
    b.*,
    numConvexityContribWeight = CASE WHEN c.sumConvexityContribWeight <> 0.0 
                                THEN b.numConvexityContrib / c.sumConvexityContribWeight
                                ELSE NULL END,
    numEffectDurationContribWeight = CASE WHEN c.sumEffectDurationContribWeight <> 0 
                                    THEN b.numEffectDurationContrib/c.sumEffectDurationContribWeight
                                    ELSE NULL END,
    -- Rating logic: instrument rating or issuer rating as fallback
    CASE WHEN ISNULL(ir.strInstRtgSPStandardized, 'NR')='NR' 
         THEN isra.strIssuerRtgSPStandardized
         ELSE ir.strInstRtgSPStandardized END strInstRtgSPStandardized,
    CASE WHEN ISNULL(ir.strInstRtgMDStandardized, 'NR')='NR' 
         THEN isra.strIssuerRtgMDStandardized
         ELSE ir.strInstRtgMDStandardized END strInstRtgMDStandardized,
    CASE WHEN ISNULL(ir.strInstRtgFHStandardized, 'NR')='NR' 
         THEN isra.strIssuerRtgFHStandardized
         ELSE ir.strInstRtgFHStandardized END strInstRtgFHStandardized
INTO #tblDMIRBKGN7tmp
FROM #tblDMIRBKGN5 b
LEFT JOIN #tblDMIRBKGN6 c ON (benchmark and currency match conditions)
LEFT JOIN DMIR.tblDMIRBRSInstRating ir ON (instrument rating conditions)
LEFT JOIN DMIR.tblDMIRBRSIssuerRating isra ON (issuer rating conditions)

-- Stage 7 final: ESG data integration
SELECT a.*, ESG.*
INTO #tblDMIRBKGN7
FROM #tblDMIRBKGN7tmp a
LEFT JOIN #ESGTable ESG ON (ESG matching conditions)
```

**Python Equivalent**:
```python
def compute_instr_indicators_bkgn_7(df_bkgn6):
    """
    Stage 7: Final processing with rating integration and ESG data.
    Equivalent to SQL BKGN_7 processing including rating logic and ESG integration.
    """
    session = get_session()
    try:
        # Step 1: Rating integration with fallback logic
        unique_instruments = df_bkgn6['numInstId'].unique().tolist()
        
        # Get instrument and issuer ratings
        rating_data = {}
        for inst_chunk in [unique_instruments[i:i+1000] for i in range(0, len(unique_instruments), 1000)]:
            rating_query = session.query(
                DMIRBRSInstrument.numInstID,
                DMIRBRSInstrument.strInstIssuerCode,
                DMIRBRSInstRating.strInstRtgSPStandardized.label('inst_sp'),
                DMIRBRSInstRating.strInstRtgMDStandardized.label('inst_md'),
                DMIRBRSInstRating.strInstRtgFHStandardized.label('inst_fh'),
                DMIRBRSIssuerRating.strIssuerRtgSPStandardized.label('issuer_sp'),
                DMIRBRSIssuerRating.strIssuerRtgMDStandardized.label('issuer_md'),
                DMIRBRSIssuerRating.strIssuerRtgFHStandardized.label('issuer_fh')
            ).outerjoin(
                DMIRBRSInstRating,
                and_(
                    DMIRBRSInstRating.strInstAladdin == DMIRBRSInstrument.strInstAladdin,
                    DMIRBRSInstRating.datInstRtgDate == df_bkgn6['datMarketDate'].iloc[0]
                )
            ).outerjoin(
                DMIRBRSIssuerRating,
                and_(
                    DMIRBRSIssuerRating.strInstIssuerCode == DMIRBRSInstrument.strInstIssuerCode,
                    DMIRBRSIssuerRating.datIssuerRtgDate == df_bkgn6['datMarketDate'].iloc[0]
                )
            ).filter(
                DMIRBRSInstrument.numInstID.in_(inst_chunk)
            ).all()
            
            for rating in rating_query:
                rating_data[rating.numInstID] = {
                    'strInstRtgSPStandardized': rating.inst_sp if rating.inst_sp and rating.inst_sp != 'NR' else rating.issuer_sp,
                    'strInstRtgMDStandardized': rating.inst_md if rating.inst_md and rating.inst_md != 'NR' else rating.issuer_md,
                    'strInstRtgFHStandardized': rating.inst_fh if rating.inst_fh and rating.inst_fh != 'NR' else rating.issuer_fh
                }
        
        # Step 2: Calculate contribution weights
        benchmark_totals = df_bkgn6.groupby(['numBenchFBAId', 'strPFCurrencyISOCode']).agg({
            'numConvexityContrib': 'sum',
            'numEffectDurationContrib': 'sum',
            'numModifDurationContrib': 'sum',
            'numMCDurationContrib': 'sum',
            'numSpreadDurationContrib': 'sum'
        }).add_suffix('_total').reset_index()
        
        # Merge benchmark totals back
        df_with_totals = df_bkgn6.merge(benchmark_totals, on=['numBenchFBAId', 'strPFCurrencyISOCode'], how='left')
        
        # Calculate contribution weights
        df_with_totals['numConvexityContribWeight'] = np.where(
            df_with_totals['numConvexityContrib_total'] != 0,
            df_with_totals['numConvexityContrib'] / df_with_totals['numConvexityContrib_total'],
            None
        )
        df_with_totals['numEffectDurationContribWeight'] = np.where(
            df_with_totals['numEffectDurationContrib_total'] != 0,
            df_with_totals['numEffectDurationContrib'] / df_with_totals['numEffectDurationContrib_total'],
            None
        )
        
        # Step 3: Merge rating data
        df_rating = pd.DataFrame.from_dict(rating_data, orient='index')
        df_rating.index.name = 'numInstId'
        df_rating = df_rating.reset_index()
        
        df_bkgn7_tmp = df_with_totals.merge(df_rating, on='numInstId', how='left')
        
        # Step 4: ESG data integration (already collected in BKGN_6)
        df_bkgn7 = df_bkgn7_tmp.copy()
        
        return df_bkgn7
    finally:
        session.close()
```
