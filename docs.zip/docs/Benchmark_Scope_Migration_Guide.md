# Benchmark Scope Migration Guide

## Overview
This document explains the migration from the SQL stored procedure `stpDMIRBenchmarkAggregate_BRS` (part 1) to the Python workflow/procedure pair: `workflow_bench_scope.py` and `procedure_bench_scope.py`.

## SQL Source
- **Stored Procedure**: `stpDMIRBenchmarkAggregate_BRS` (part 1)
- **SQL File**: `dags/sql/stpDMIRBenchmarkAggregate_BRS.sql`
- **Lines Covered**: 1-400 (scope identification and speed processing logic)
- **Purpose**: Identify benchmark universe for aggregate calculation, including speed processing and standard scope definition

## Python Implementation

### Workflow File
- **File**: `dags/benchmark_aggregates_holdings/workflow_bench_scope.py`
- **Purpose**: Airflow task orchestration for benchmark scope identification

### Procedure File
- **File**: `dags/benchmark_aggregates_holdings/procedure_bench_scope.py`
- **Purpose**: Core business logic for scope computation and benchmark universe definition

---

## 1. Tables Used as Inputs

| Table Name                              | Description                                                                                                          |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **DMIR.tblDMIRSpeedProcsParam**        | Speed processing parameters: defines benchmarks requiring expedited processing with specific dates                  |
| **DWGN.typDWGNPeriod**                 | Period master: provides monthly and weekly date ranges with previous period mappings for scope calculation         |
| **DMIR.tblDMIRBRSBenchmarkConstituent** | Benchmark constituents: contains constituent data with market dates for determining benchmark processing needs      |
| **DMIR.tblDMIRReportRequest**          | Report requests: defines which benchmarks need weekly processing vs standard monthly processing                     |
| **DWGN.tblDWGNBenchMark**              | Benchmark master: provides benchmark metadata including currency information for scope definition                  |
| **DMIR.vieDMIRBRSCurrencyQuote**       | Currency quotes: provides exchange rates for benchmark currency conversion in scope calculations                    |
| **DMIR.tblDMIRBRSBenchIndicators**     | Existing indicators: used to avoid recalculating already-processed benchmark aggregates                            |
| **DMIR.tblDMIRBRSInstAnalytic**        | Instrument analytics: used to identify benchmarks with recent analytics updates requiring recalculation            |

---

## 2. Target Tables

- **DMIR.tblDMIRBenchScopeAG**  
  *In Python:* populated via multiple scope computation functions with benchmark processing candidates.  
  *Description:* Central scope table defining which benchmarks need aggregate calculation for which periods with currency and audit information.

- **DMIR.tblDMIRReportRequest**  
  *In Python:* updated via speed scope processing to include missing on-demand benchmarks.  
  *Description:* receives new report request entries for benchmarks identified in speed processing but missing from standard requests.

- **DMIR.tblDMIRSpeedProcsParam**  
  *In Python:* cleaned up after speed processing completion via deletion operations.  
  *Description:* temporary parameter table cleared after speed benchmarks are processed to avoid duplicate processing.

---

## 3. Temporary (Staging) Tables / DataFrames

| Staging Table (SQL)                    | Purpose / Description                                                                                                | Equivalent pandas DataFrame(s)                      |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| **#BenchScopeAG**                     | Working scope table: collects all benchmarks requiring processing with period and currency information             | `df_scope_combined` in final scope assembly         |
| **#speed_scope_to_run**               | Speed processing candidates: benchmarks requiring expedited processing with specific periods                        | `df_speed_scope` in `compute_speed_scope_size()`    |
| **#months**                           | Monthly periods: standard monthly reporting periods with previous period mappings                                   | `df_months` in `compute_months()`                   |
| **#weeks**                            | Weekly periods: Friday-ending weekly periods for benchmarks requiring weekly processing                             | `df_weeks` in `compute_weeks()`                     |
| **#newBenchConstits**                 | Constituent analysis: benchmarks with recent constituent data needing aggregate recalculation                       | `df_newBenchConstits` in benchmark constituent processing |
| **#whichBenchWeekly**                 | Weekly benchmark filter: benchmarks specifically requiring weekly vs monthly processing                             | `df_weekly_benchmarks` in weekly scope processing   |
| **#upd_analytics / #upd_analytics_v2** | Analytics updates: benchmarks with recent instrument analytics updates requiring scope inclusion                     | `df_recent_analytics` in analytics-based scope updates |
| *currency staging*                     | Currency conversion data for benchmark scope with proper exchange rates                                             | `df_currency_rates` in scope currency processing    |
| *existing aggregates filter*          | Previously calculated aggregates to avoid duplicate processing                                                       | `df_existing_indicators` in duplicate avoidance logic |

---

## 4. Task Breakdown for the Airflow DAG

| Task Name (`@task`)                              | Description                                                                                                                                                                                                                      | Inputs / Outputs                                                    | Parallelizable?                                    |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- | -------------------------------------------------- |
| **task__start_group**                           | Initialize scope processing: log start of benchmark scope identification workflow                                                                                                                                               | **In:** audit_id from params <br>**Out:** logging status           | ❌ (workflow initialization must run first)       |
| **task__compute_speed_scope_size**              | Speed scope analysis: identify benchmarks in speed processing queue and count for capacity planning                                                                                                                            | **In:** audit_id <br>**Out:** `df_speed_scope`, `nr_speed_bm_to_run` | ❌ (determines processing mode for all downstream) |
| **task__compute_speed_scope**                   | Speed scope execution: process speed benchmarks if count > 0 and time restrictions allow (before 18h)                                                                                                                         | **In:** `force_full_scope`, `nr_speed_bm_to_run` <br>**Out:** speed scope processing status | ❌ (conditional on speed scope analysis)          |
| **task__first_cleanup_standard_scope**         | Standard scope initialization: clear existing scope data to prepare for fresh scope calculation                                                                                                                                | **In:** none <br>**Out:** cleanup status                          | ❌ (must run before scope building)               |
| **task__compute_months**                        | Monthly period calculation: identify monthly reporting periods based on calculation horizon                                                                                                                                     | **In:** months_to_calc parameter <br>**Out:** `df_months`          | ✔️ (independent period calculation)               |
| **task__compute_weeks**                         | Weekly period calculation: identify Friday-ending weekly periods for weekly benchmark processing                                                                                                                                | **In:** months_to_calc parameter <br>**Out:** `df_weeks`           | ✔️ (independent period calculation)               |
| **task__compute_max_market_date_per_benchmark** | Constituent analysis: find latest market dates per benchmark to determine processing candidates                                                                                                                                 | **In:** `df_months` <br>**Out:** `df_newBenchConstits`             | ✔️ (can process month periods in parallel)       |
| **task__add_weekly_benchmarks_from_report_request** | Weekly scope addition: add benchmarks specifically requiring weekly processing from report requests                                                                                                                             | **In:** `df_weeks`, report request data <br>**Out:** combined weekly scope | ✔️ (independent of monthly processing)           |
| **task__remove_existing_aggregates_from_scope** | Duplicate prevention: filter out benchmarks with existing up-to-date aggregates to avoid redundant processing                                                                                                                  | **In:** `df_newBenchConstits` <br>**Out:** filtered scope          | ✔️ (can check existing aggregates in parallel)   |
| **task__compute_scope_with_recent_analytics_updates** | Analytics-driven inclusion: add benchmarks with recent instrument analytics updates requiring recalculation                                                                                                                     | **In:** period data, analytics timestamps <br>**Out:** analytics-based scope additions | ✔️ (independent analytics analysis)              |
| **task__add_speed_scope_into_standard_scope**  | Scope consolidation: merge standard scope with any remaining speed scope requirements                                                                                                                                          | **In:** standard scope, speed scope <br>**Out:** consolidated scope | ❌ (requires both standard and speed scope data)  |
| **task__recompute_scope_with_esg_change**      | ESG impact analysis: include benchmarks affected by recent ESG data changes requiring aggregate recalculation                                                                                                                  | **In:** scope data, ESG change indicators <br>**Out:** ESG-enhanced scope | ✔️ (independent ESG change analysis)             |
| **task__final_cleanup_scope**                  | Scope finalization: populate final scope table with currency rates and audit information, cleanup temporary data                                                                                                               | **In:** consolidated scope <br>**Out:** finalized `tblDMIRBenchScopeAG` | ❌ (final atomic scope population)               |
| **task__end_group**                            | Workflow completion: log successful completion of benchmark scope identification                                                                                                                                                | **In:** none <br>**Out:** completion status                        | ❌ (workflow finalization)                        |

> **Speed vs Standard Processing**  
> The workflow supports two modes: speed processing (for urgent benchmarks) and standard processing (full scope calculation). Speed processing bypasses most scope logic and directly processes specified benchmarks.

> **Time Restrictions**  
> Speed processing only runs before 18h to avoid conflicts with overnight operations. After 18h, the system defaults to standard scope processing.

> **Concurrency Notes**  
> - **Period Calculations**: Monthly and weekly period identification can run in parallel  
> - **Benchmark Analysis**: Constituent analysis and analytics updates can be processed concurrently  
> - **Scope Filtering**: Existing aggregate checks and ESG change analysis are independent operations  
> - **Final Consolidation**: Scope merge and final population must be sequential for data consistency

---

## 5. High‑Level DAG Structure Diagram

```text
      ┌─────────────────────────────────────────┐
      │ task__start_group                       │
      │ (initialize scope processing)           │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_speed_scope_size          │
      │ (analyze speed processing queue)        │
      └─────────────────────────────────────────┘
                    ↙            ↘
      ┌──────────────────┐    ┌─────────────────────────────────────────┐
      │ task__compute_   │    │ task__first_cleanup_standard_scope     │
      │ speed_scope      │    │ (clear existing scope)                 │
      │ (if speed > 0)   │    └─────────────────────────────────────────┘
      └──────────────────┘                   ↓
             ↓                     ┌─────────────────────────────────────────┐
             │                     │        Parallel Period Processing       │
             │                     │  ┌─────────────────────────────────────┐ │
             │                     │  │ task__compute_months                │ │
             │                     │  │ task__compute_weeks                 │ │
             │                     │  └─────────────────────────────────────┘ │
             │                     └─────────────────────────────────────────┘
             │                                      ↓
             │                     ┌─────────────────────────────────────────┐
             │                     │     Parallel Benchmark Analysis        │
             │                     │  ┌─────────────────────────────────────┐ │
             │                     │  │ task__compute_max_market_date_per_  │ │
             │                     │  │ benchmark                           │ │
             │                     │  │ task__add_weekly_benchmarks_from_   │ │
             │                     │  │ report_request                      │ │
             │                     │  └─────────────────────────────────────┘ │
             │                     └─────────────────────────────────────────┘
             │                                      ↓
             │                     ┌─────────────────────────────────────────┐
             │                     │      Parallel Scope Refinement         │
             │                     │  ┌─────────────────────────────────────┐ │
             │                     │  │ task__remove_existing_aggregates_   │ │
             │                     │  │ from_scope                          │ │
             │                     │  │ task__compute_scope_with_recent_    │ │
             │                     │  │ analytics_updates                   │ │
             │                     │  │ task__recompute_scope_with_esg_     │ │
             │                     │  │ change                              │ │
             │                     │  └─────────────────────────────────────┘ │
             │                     └─────────────────────────────────────────┘
             │                                      ↓
             └──────────────────→  ┌─────────────────────────────────────────┐
                                   │ task__add_speed_scope_into_standard_    │
                                   │ scope (consolidation)                   │
                                   └─────────────────────────────────────────┘
                                                  ↓
                                   ┌─────────────────────────────────────────┐
                                   │ task__final_cleanup_scope               │
                                   │ (populate final scope table)           │
                                   └─────────────────────────────────────────┘
                                                  ↓
                                   ┌─────────────────────────────────────────┐
                                   │ task__end_group                         │
                                   │ (completion logging)                    │
                                   └─────────────────────────────────────────┘
```

---

## 6. Functional Mapping Details

### 1. Speed Processing Detection and Execution
**SQL Section**: Lines 118-150 (speed processing logic with time restrictions)  
**Python Implementation**: `compute_speed_scope_size()` and speed processing tasks

**SQL Logic**:
```sql
CREATE TABLE #speed_scope_to_run
(
  datPeriodLastDay DATE NULL,
  numBenchFBAId INTEGER NULL
)

insert #speed_scope_to_run
select distinct datPeriodLastDay, numBenchFBAId
from DMIR.tblDMIRSpeedProcsParam
where strProcType='AGG' and strSource='BM'

declare @nr_speed_bm_to_run int = (select count(*) from #speed_scope_to_run)

-- if time > 18h put @nr_speed_bm_to_run = 0
if datepart(hour, @dateTimeNow) > 18 set @nr_speed_bm_to_run = 0
```

**Python Equivalent**:
```python
def compute_speed_scope_size(audit_id):
    # Get speed scope from DMIR.tblDMIRSpeedProcsParam
    speed_scope_query = (
        session.query(DMIRSpeedProcsParam.datPeriodLastDay, DMIRSpeedProcsParam.numBenchFBAId)
        .distinct()
        .filter(DMIRSpeedProcsParam.strProcType == "AGG", DMIRSpeedProcsParam.strSource == "BM")
    )
    
    df_speed_scope = pd.DataFrame(speed_scope_query.all(), columns=["datPeriodLastDay", "numBenchFBAId"])
    return df_speed_scope

@task
def task__compute_speed_scope(**kwargs):
    nr_speed_bm_to_run = kwargs["ti"].xcom_pull(key="nr_speed_bm_to_run")
    current_hour = datetime.now().hour
    
    # Time restriction: no speed processing after 18h
    if current_hour > 18:
        nr_speed_bm_to_run = 0
```

### 2. Standard Scope Period Calculation
**SQL Section**: Lines 175-210 (monthly and weekly period identification)  
**Python Implementation**: `compute_months()` and `compute_weeks()`

**SQL Logic**:
```sql
select 'M' as strFreq
,datPerioddate as datPeriodLastDay
,datPeriodPrevReportMonth as datPrevPeriodLastDay 
into #months
from DWGN.typDWGNPeriod
where datPerioddate 
  between dateadd(mm, -@monthsToCalc + 1, dateadd(dd, -day(@today), @today))
  and dateadd(dd, -day(@today), @today)
and blnIsmonth=1

select 'W' as strFreq
,datPerioddate as datPeriodLastDay
,datPeriodPrevReportWeek as datPrevPeriodLastDay
into #weeks
from DWGN.typDWGNPeriod
where datPerioddate between dateadd(WEEK,-@monthsToCalc * 5, @today) and @today
and blnIsFriday = 1
```

**Python Equivalent**:
```python
def compute_months(start_date, end_date):
    query_months = session.query(
        literal("M").label("strFreq"),
        DWGNTypPeriod.datPerioddate.label("datPeriodLastDay"),
        DWGNTypPeriod.datPeriodPrevReportMonth.label("datPrevPeriodLastDay"),
    ).filter(
        DWGNTypPeriod.datPerioddate.between(start_date, end_date), 
        DWGNTypPeriod.blnIsmonth == 1
    )
    return get_all_as_df(query_months)

def compute_weeks(start_date, end_date, months_to_calc):
    query_weeks = session.query(
        literal("W").label("strFreq"),
        DWGNTypPeriod.datPerioddate.label("datPeriodLastDay"),
        DWGNTypPeriod.datPeriodPrevReportWeek.label("datPrevPeriodLastDay"),
    ).filter(
        DWGNTypPeriod.datPerioddate.between(
            (datetime.strptime(end_date, "%Y-%m-%d") - timedelta(weeks=5)).strftime("%Y-%m-%d"),
            end_date,
        ),
        DWGNTypPeriod.blnIsFriday == 1,
    )
    return get_all_as_df(query_weeks)
```

### 3. Benchmark Constituent Analysis
**SQL Section**: Lines 211-235 (max market date per benchmark identification)  
**Python Implementation**: `compute_max_market_date_per_benchmark()`

**SQL Logic**:
```sql
select  
m.strFreq, m.datPeriodLastDay, m.datPrevPeriodLastDay,
comp.numBenchFBAId,
max(comp.datMarketDate) as maxDatMarketDate,
max(comp.numAuditId) as maxNumAuditId
into #newBenchConstits
from #months m
inner join DMIR.tblDMIRBRSBenchmarkConstituent comp 
    on comp.datMarketDate between m.datPrevPeriodLastDay and m.datPeriodLastDay
group by m.strFreq, m.datPeriodLastDay, m.datPrevPeriodLastDay, comp.numBenchFBAId
```

**Python Equivalent**:
```python
def compute_max_market_date_per_benchmark(df_months):
    bench_constits_list = []
    
    for _, m_row in df_months.iterrows():
        constituents_query = (
            session.query(
                DMIRBRSBenchmarkConstituent.numBenchFBAId,
                func.max(DMIRBRSBenchmarkConstituent.datMarketDate).label("maxDatMarketDate"),
                func.max(DMIRBRSBenchmarkConstituent.numAuditId).label("maxNumAuditId"),
            )
            .filter(
                DMIRBRSBenchmarkConstituent.datMarketDate >= m_row["datPrevPeriodLastDay"],
                DMIRBRSBenchmarkConstituent.datMarketDate <= m_row["datPeriodLastDay"],
            )
            .group_by(DMIRBRSBenchmarkConstituent.numBenchFBAId)
        )
        
        for benchmark_data in constituents_query.all():
            bench_constits_list.append({
                "strFreq": m_row["strFreq"],
                "datPeriodLastDay": m_row["datPeriodLastDay"],
                "datPrevPeriodLastDay": m_row["datPrevPeriodLastDay"],
                "numBenchFBAId": benchmark_data.numBenchFBAId,
                "maxDatMarketDate": benchmark_data.maxDatMarketDate,
                "maxNumAuditId": benchmark_data.maxNumAuditId,
            })
    
    return pd.DataFrame(bench_constits_list)
```

### 4. Existing Aggregate Filtering
**SQL Section**: Lines 250-260 (exclude already calculated aggregates)  
**Python Implementation**: `remove_existing_aggregates_from_scope()`

**SQL Logic**:
```sql
delete #newBenchConstits
where exists (select 1 from DMIR.tblDMIRBRSBenchIndicators bi
                        where bi.strPeriodTypeFlag = #newBenchConstits.strFreq
                            and bi.datPeriodLastDay =  #newBenchConstits.datPeriodLastDay
                            and bi.numBenchFBAId = #newBenchConstits.numBenchFBAId
                            and bi.datMarketDate = #newBenchConstits.maxDatMarketDate
                            and bi.numAuditId >= #newBenchConstits.maxNumAuditId
                )
```

**Python Equivalent**:
```python
def remove_existing_aggregates_from_scope(df_newBenchConstits):
    # Build exclusion criteria by checking existing indicators
    exclusion_conditions = []
    
    for _, row in df_newBenchConstits.iterrows():
        existing_query = session.query(DMIRBRSBenchIndicators.numBenchFBAId).filter(
            DMIRBRSBenchIndicators.strPeriodTypeFlag == row["strFreq"],
            DMIRBRSBenchIndicators.datPeriodLastDay == row["datPeriodLastDay"],
            DMIRBRSBenchIndicators.numBenchFBAId == row["numBenchFBAId"],
            DMIRBRSBenchIndicators.datMarketDate == row["maxDatMarketDate"],
            DMIRBRSBenchIndicators.numAuditId >= row["maxNumAuditId"]
        )
        
        if existing_query.first():
            exclusion_conditions.append(row.name)  # Mark for exclusion
    
    # Filter out existing aggregates
    df_filtered = df_newBenchConstits.drop(exclusion_conditions)
    return df_filtered
```

### 5. Final Scope Population with Currency Data
**SQL Section**: Lines 260-275 (final scope insertion with currency conversion)  
**Python Implementation**: `final_cleanup_scope()`

**SQL Logic**:
```sql
INSERT INTO DMIR.tblDMIRBenchScopeAG 
(strPeriodTypeFlag,datPeriodLastDay,numBenchMarkId,numPFCurrencyID,strPFCurrencyISOCode,numPFCurrencyRate,numAuditId,numCalcStatus,datCalculation)
select distinct 
  bc.strFreq,
  bc.datPeriodLastDay,
  bc.numBenchFBAId,
  isnull(b.numCurrencyId,35660),
  isnull(c.strCurrCode,'EUR'),
  isnull(c.numccyqRate,1),
  @numAuditId,
  null,
  null
from #newBenchConstits bc, DWGN.tblDWGNBenchMark b, DMIR.vieDMIRBRSCurrencyQuote c
  where b.numBenchId = bc.numBenchFBAId
  and c.numCurrencyID = b.numCurrencyId
  and c.datccyqDate = (select max(datccyqDate) from  DMIR.vieDMIRBRSCurrencyQuote 
                      where datccyqDate > bc.datPrevPeriodLastDay
                      and datccyqDate <= bc.datPeriodLastDay)
```

**Python Equivalent**:
```python
def final_cleanup_scope(df_consolidated_scope, audit_id):
    # Prepare scope records with currency information
    scope_records = []
    
    for _, row in df_consolidated_scope.iterrows():
        # Get benchmark currency information
        benchmark_query = session.query(DWGNBenchMark).filter(
            DWGNBenchMark.numBenchId == row["numBenchFBAId"]
        ).first()
        
        # Get latest currency rate for the period
        currency_rate_query = session.query(DMIRBRSCurrencyQuote).filter(
            DMIRBRSCurrencyQuote.numCurrencyID == benchmark_query.numCurrencyId,
            DMIRBRSCurrencyQuote.datccyqDate > row["datPrevPeriodLastDay"],
            DMIRBRSCurrencyQuote.datccyqDate <= row["datPeriodLastDay"]
        ).order_by(DMIRBRSCurrencyQuote.datccyqDate.desc()).first()
        
        scope_record = DMIRBenchScopeAG(
            strPeriodTypeFlag=row["strFreq"],
            datPeriodLastDay=row["datPeriodLastDay"],
            numBenchMarkId=row["numBenchFBAId"],
            numPFCurrencyID=benchmark_query.numCurrencyId if benchmark_query else 35660,
            strPFCurrencyISOCode=currency_rate_query.strCurrCode if currency_rate_query else 'EUR',
            numPFCurrencyRate=currency_rate_query.numccyqRate if currency_rate_query else 1,
            numAuditId=audit_id,
            numCalcStatus=None,
            datCalculation=None
        )
        scope_records.append(scope_record)
    
    # Bulk insert scope records
    session.bulk_save_objects(scope_records)
    session.commit()
```

---

## 7. Key Data Transformations

### 1. Speed vs Standard Processing Mode Selection
**SQL**: Time-based conditional logic with hard-coded hour check
```sql
if datepart(hour, @dateTimeNow) > 18 set @nr_speed_bm_to_run = 0

if @nr_speed_bm_to_run > 0
begin
  -- Speed processing logic
end
else
begin  
  -- Standard scope calculation
end
```

**Python**: Dynamic mode determination with configurable parameters
```python
current_hour = datetime.now().hour
force_full_scope = int(kwargs["params"]["force_full_scope"])

if current_hour > 18 or force_full_scope:
    # Standard processing mode
    df_speed_scope = pd.DataFrame()  # Empty speed scope
else:
    # Speed processing mode
    df_speed_scope = compute_speed_scope_size(audit_id)

# Mode selection influences entire downstream processing
processing_mode = "SPEED" if len(df_speed_scope) > 0 else "STANDARD"
```

### 2. Period Range Calculation Strategy
**SQL**: Fixed date arithmetic with hard-coded month calculations
```sql
select datPerioddate
from DWGN.typDWGNPeriod
where datPerioddate 
  between dateadd(mm, -@monthsToCalc + 1, dateadd(dd, -day(@today), @today))
  and dateadd(dd, -day(@today), @today)
```

**Python**: Flexible date calculation with relativedelta for accuracy
```python
# More precise date calculations
today = get_date_pivot(audit_id)[0].date()
start_of_current_month = today.replace(day=1)
months_back = relativedelta(months=months_to_calc - 1)
start_date = start_of_current_month - months_back
end_date = start_of_current_month - relativedelta(days=1)

# Query periods with calculated range
query_months = session.query(...).filter(
    DWGNTypPeriod.datPerioddate.between(start_date, end_date)
)
```

### 3. Benchmark Scope Consolidation
**SQL**: Single large INSERT statement with complex joins
```sql
INSERT INTO DMIR.tblDMIRBenchScopeAG (...)
select distinct bc.strFreq, bc.datPeriodLastDay, bc.numBenchFBAId, ...
from #newBenchConstits bc, DWGN.tblDWGNBenchMark b, DMIR.vieDMIRBRSCurrencyQuote c
where b.numBenchId = bc.numBenchFBAId
  and c.numCurrencyID = b.numCurrencyId
  and c.datccyqDate = (select max(datccyqDate) ...)
```

**Python**: Modular DataFrame operations with explicit error handling
```python
# Separate currency lookup and benchmark processing
df_benchmarks = pd.merge(
    df_consolidated_scope, 
    df_benchmark_master, 
    left_on="numBenchFBAId", 
    right_on="numBenchId", 
    how="left"
)

# Separate currency rate resolution
df_with_rates = pd.merge(
    df_benchmarks,
    df_currency_rates,
    on=["numCurrencyId", "period_range"],
    how="left"
)

# Fill missing values with defaults
df_final = df_with_rates.fillna({
    'numCurrencyId': 35660,
    'strCurrCode': 'EUR', 
    'numccyqRate': 1
})

# Bulk insert with validation
scope_records = df_final.to_dict('records')
session.bulk_insert_mappings(DMIRBenchScopeAG, scope_records)
```
