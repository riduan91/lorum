# Benchmark Indicators Migration Guide

## Overview
This document explains the migration from the SQL stored procedure `stpDMIRBenchmarkAggregate_BRS` (part 3) to the Python workflow/procedure pair: `workflow_bench_indicators.py` and `procedure_bench_indicators.py`.

## SQL Source
- **Stored Procedure**: `stpDMIRBenchmarkAggregate_BRS` (part 3)
- **SQL File**: `dags/sql/stpDMIRBenchmarkAggregate_BRS.sql`
- **Lines Covered**: 1690-2489 (benchmark-level indicator aggregation with rating analysis and ESG processing)
- **Purpose**: Benchmark-level aggregate indicator computation including rating analysis, ESG metrics aggregation, and final data persistence

## Python Implementation

### Workflow File
- **File**: `dags/benchmark_aggregates_holdings/workflow_bench_indicators.py`
- **Purpose**: Airflow task orchestration for benchmark aggregate indicator computation

### Procedure File
- **File**: `dags/benchmark_aggregates_holdings/procedure_bench_indicators.py`
- **Purpose**: Core business logic for benchmark-level indicator aggregation and rating analysis

---

## 1. Tables Used as Inputs

| Table Name                              | Description                                                                                                          |
| --------------------------------------- | -------------------------------------------------------------------------------------------------------------------- |
| **DMIR.tblDMIRBenchScopeAG**           | Benchmark scope: defines which benchmarks need indicator aggregation for which periods                              |
| **DMIR.tblDMIRBRSBenchInstrIndicators** | Source instrument indicators: output from instrument indicators workflow containing detailed instrument-level data  |
| **DMIR.tblDMIRBRSBenchIndicators**     | Historical benchmark indicators: existing benchmark-level data for market cap and fundamental metrics updates      |
| **Rating Mapping Tables**              | Rating standardization: mapping tables for converting numeric ratings back to standardized rating strings          |
| **ESG Aggregation Sources**            | ESG data consolidation: instrument-level ESG scores for benchmark-level aggregation                                |
| **Engagement Data Tables**             | ESG engagement metrics: engagement scores and meeting data for stewardship indicator calculation                    |

---

## 2. Target Tables

- **DMIR.tblDMIRBRSBenchIndicators**  
  *In Python:* populated via multi-stage rating analysis and ESG aggregation pipeline.  
  *Description:* Final repository for benchmark-level indicators including aggregated analytics, ESG scores, rating distributions, and performance metrics.

---

## 3. Temporary (Staging) Tables / DataFrames

| Staging Table (SQL)                    | Purpose / Description                                                                                                | Equivalent pandas DataFrame(s)                      |
| -------------------------------------- | -------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| **#tblDMIRBKGN8**                     | Stage 8: Rating weighted calculations with numeric rating mappings for benchmark average rating computation         | `df_tblDMIRBKGN8` in `compute_bench_indicators_bkgn_8()` |
| **#IRRatings**                        | Rating reference: master rating scale with numeric equivalents for rating calculations                              | `df_IRRatings` in rating processing functions        |
| **#IRRatingsBetween**                 | Rating interpolation: rating ranges for converting numeric averages back to rating strings                         | `df_IRRatingsBetween` in rating conversion logic     |
| **#tblDMIRBKGN9**                     | Stage 9: Benchmark average ratings with interpolated rating strings based on weighted numeric calculations         | `df_tblDMIRBKGN9` in `compute_bench_indicators_bkgn_9()` |
| **#tblDMIRBKGN10**                    | Stage 10: Aggregated benchmark metrics including duration, yield, convexity, and fundamental indicators            | `df_tblDMIRBKGN10` in `compute_bench_indicators_bkgn_10()` |
| **#esg_aggregated_data**              | ESG aggregation: consolidated ESG metrics aggregated from instrument-level data to benchmark level                 | `df_esg_aggregated` in ESG aggregation functions     |
| **#esg_engagement**                   | ESG engagement: engagement scores and stewardship metrics aggregated by benchmark                                  | `df_esg_engagement` in engagement processing         |
| **tblDMIRBenchIndicatorsWrk**         | Working table: intermediate benchmark indicators before final validation and insertion                              | `df_benchmark_work` in final processing pipeline     |

---

## 4. Task Breakdown for the Airflow DAG

| Task Name (`@task`)                              | Description                                                                                                                                                                                                                      | Inputs / Outputs                                                    | Parallelizable?                                    |
| ------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- | -------------------------------------------------- |
| **task__start_group**                           | Initialize benchmark indicator processing: log workflow start and validate input data from instrument indicators workflow                                                                                                       | **In:** audit_id from params <br>**Out:** initialization status    | ❌ (workflow initialization)                       |
| **task__compute_bench_indicators_bkgn_8**       | **Stage 8**: Rating weighted calculations - convert ratings to numeric values, calculate position-weighted ratings for benchmark average computation                                                                          | **In:** BKGN_7 data <br>**Out:** `df_tblDMIRBKGN8`, `df_IRRatings` | ✔️ (rating calculations can be parallelized by rating agency) |
| **task__compute_bench_indicators_bkgn_9**       | **Stage 9**: Rating interpolation - convert weighted numeric ratings back to standardized rating strings using rating scale interpolation                                                                                     | **In:** `df_tblDMIRBKGN8`, `df_IRRatingsBetween` <br>**Out:** `df_tblDMIRBKGN9` | ✔️ (interpolation can be parallelized by benchmark) |
| **task__compute_bench_indicators_bkgn_10**      | **Stage 10**: Aggregate analytics - calculate benchmark-level duration, yield, convexity, and other aggregate metrics from instrument-level data                                                                             | **In:** BKGN_7 data <br>**Out:** `df_tblDMIRBKGN10`                | ✔️ (mathematical aggregations can be parallelized) |
| **task__aggregate_esg_indicators**              | ESG aggregation: consolidate instrument-level ESG scores, CO2 data, controversy scores, and sustainability metrics to benchmark level                                                                                         | **In:** instrument ESG data <br>**Out:** `df_esg_aggregated`       | ✔️ (ESG metrics can be aggregated in parallel)     |
| **task__compute_esg_engagement**                | ESG engagement processing: aggregate engagement scores, stewardship activities, and meeting data for benchmark-level engagement indicators                                                                                     | **In:** instrument engagement data <br>**Out:** `df_esg_engagement` | ✔️ (engagement calculations can be parallelized)  |
| **task__merge_fundamental_data**                | Fundamental data integration: merge existing fundamental metrics (P/E, P/B, dividend yield) from historical benchmark indicators                                                                                               | **In:** benchmark work data <br>**Out:** enhanced benchmark data    | ✔️ (fundamental metrics can be processed in parallel) |
| **task__final_delete_and_insert_indicators**   | Data persistence: delete existing benchmark indicators for processed scope and insert new calculated indicators with audit trails                                                                                              | **In:** final benchmark data <br>**Out:** insertion status         | ❌ (database operations must be atomic)           |
| **task__validate_indicators**                  | Post-processing validation: validate benchmark indicators against data quality rules and generate processing metrics                                                                                                           | **In:** inserted indicators <br>**Out:** validation results        | ✔️ (validation rules can be checked in parallel)  |
| **task__end_group**                             | Workflow completion: log successful completion and final processing statistics                                                                                                                                                  | **In:** final status <br>**Out:** completion metrics               | ❌ (workflow finalization)                         |

> **Rating Processing Architecture**  
> The rating analysis pipeline (BKGN_8 and BKGN_9) implements complex rating arithmetic:
> - **Rating to Numeric**: Convert standardized ratings (AAA, AA+, etc.) to numeric scales for mathematical operations
> - **Weighted Averaging**: Calculate position-weighted average ratings using instrument weights
> - **Rating Interpolation**: Convert numeric averages back to rating strings using between-rating logic
> - **Multi-Agency Support**: Process ratings from S&P, Moody's, Fitch, and up to 13 custom rating systems

> **ESG Aggregation Workflow**  
> ESG processing consolidates sustainability metrics from instrument to benchmark level:
> - **Coverage Weighting**: Weight ESG scores by instrument position size for representative benchmark scores
> - **Multi-Metric Integration**: Aggregate environmental, social, governance scores separately and combined
> - **Engagement Processing**: Calculate stewardship metrics including engagement activities and meeting counts
> - **Controversy Analysis**: Aggregate controversy exposure and risk scores across benchmark constituents

> **Concurrency Notes**  
> - **Rating Calculations**: Different rating agencies can be processed in parallel
> - **ESG Aggregation**: Environmental, social, and governance metrics can be calculated concurrently  
> - **Fundamental Metrics**: Market cap, P/E, dividend yield calculations can be parallelized
> - **Benchmark Processing**: Multiple benchmarks can be processed through stages simultaneously

---

## 5. High‑Level DAG Structure Diagram

```text
      ┌─────────────────────────────────────────┐
      │ task__start_group                       │
      │ (initialize benchmark processing)       │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_bench_indicators_bkgn_8   │
      │ Stage 8: Rating Weighted Calculations   │
      │ • Convert ratings to numeric values     │
      │ • Calculate weighted average ratings    │
      │ • Process multiple rating agencies      │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__compute_bench_indicators_bkgn_9   │
      │ Stage 9: Rating Interpolation           │
      │ • Convert numeric ratings to strings    │
      │ • Apply rating scale interpolation      │
      │ • Standardize rating representations    │
      └─────────────────────────────────────────┘
                         ↓
   ┌──────────────────┬─────────────────────────────────┬──────────────────┐
   ▼                  ▼                                 ▼                  ▼
┌─────────────────┐ ┌─────────────────────────────────┐ ┌────────────────┐ ┌────────────────┐
│ BKGN_10:        │ │ task__aggregate_esg_indicators  │ │ ESG Engagement │ │ Fundamental    │
│ Analytics       │ │ • ESG score aggregation         │ │ • Stewardship  │ │ Data Merge     │
│ • Duration      │ │ • CO2 intensity metrics         │ │ • Meeting data │ │ • P/E ratios   │
│ • Yield         │ │ • Controversy scores            │ │ • Engagement   │ │ • Market caps  │
│ • Convexity     │ │ • Sustainability metrics        │ │   activities   │ │ • Dividend yld │
└─────────────────┘ └─────────────────────────────────┘ └────────────────┘ └────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__final_delete_and_insert_indicators│
      │ • Delete existing benchmark indicators  │
      │ • Insert new calculated indicators      │
      │ • Apply audit trails and timestamps    │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__validate_indicators               │
      │ • Validate data quality                 │
      │ • Check coverage percentages            │
      │ • Generate processing metrics           │
      └─────────────────────────────────────────┘
                         ↓
      ┌─────────────────────────────────────────┐
      │ task__end_group                         │
      │ (completion and logging)                │
      └─────────────────────────────────────────┘
```

---

## 6. Functional Mapping Details

### 1. Rating Weighted Calculations (BKGN_8)
**SQL Section**: Lines 1690-1800 (numeric rating conversion and weighted averaging)  
**Python Implementation**: `compute_bench_indicators_bkgn_8()`

**SQL Logic**:
```sql
-- Rating reference table creation
CREATE TABLE #IRRatings (
    nbr int,
    strRatingAgency varchar(20),
    strRating varchar(20),
    numRating float
)

-- Convert ratings to numeric and calculate weighted averages
SELECT 
    a.numBenchFBAId,
    a.strCompositionCd,
    a.datReportingDay,
    a.numweight,
    isnull(sp.numRating,0) numRatingSP,
    numWeightSP = CASE WHEN isnull(sp.numRating,0) <> 0 THEN a.numweight ELSE 0 END,
    numRatingWeightSP = isnull(a.numweight * isnull(sp.numRating,0),0),
    -- Similar logic for Moody's, Fitch, and custom ratings
    isnull(md.numRating,0) numRatingMD,
    numWeightMD = CASE WHEN isnull(md.numRating,0) <> 0 THEN a.numweight ELSE 0 END,
    numRatingWeightMD = isnull(a.numweight * isnull(md.numRating,0),0)
INTO #tblDMIRBKGN8
FROM #tblDMIRBKGN7 a
LEFT JOIN #IRRatings sp ON (a.strInstRtgSPStandardized = sp.strRating AND sp.strRatingAgency = 'SP')
LEFT JOIN #IRRatings md ON (a.strInstRtgMDStandardized = md.strRating AND md.strRatingAgency = 'MOODY')
```

**Python Equivalent**:
```python
def compute_bench_indicators_bkgn_8(df_bkgn7):
    """
    Stage 8: Convert ratings to numeric values and calculate weighted averages.
    Equivalent to SQL BKGN_8 processing with rating arithmetic.
    """
    # Create rating reference mapping
    rating_mappings = create_rating_reference_tables()
    df_IRRatings = pd.DataFrame([
        {'nbr': 1, 'strRatingAgency': 'SP', 'strRating': 'AAA', 'numRating': 1.0},
        {'nbr': 2, 'strRatingAgency': 'SP', 'strRating': 'AA+', 'numRating': 2.0},
        {'nbr': 3, 'strRatingAgency': 'SP', 'strRating': 'AA', 'numRating': 3.0},
        # ... complete rating scale
        {'nbr': 1, 'strRatingAgency': 'MOODY', 'strRating': 'Aaa', 'numRating': 1.0},
        {'nbr': 2, 'strRatingAgency': 'MOODY', 'strRating': 'Aa1', 'numRating': 2.0},
        # ... complete Moody's scale
    ])
    
    # Merge rating numeric values for S&P
    sp_ratings = df_IRRatings[df_IRRatings['strRatingAgency'] == 'SP'][['strRating', 'numRating']]
    sp_ratings.columns = ['strInstRtgSPStandardized', 'numRatingSP']
    
    # Merge rating numeric values for Moody's  
    md_ratings = df_IRRatings[df_IRRatings['strRatingAgency'] == 'MOODY'][['strRating', 'numRating']]
    md_ratings.columns = ['strInstRtgMDStandardized', 'numRatingMD']
    
    # Merge rating numeric values for Fitch
    fh_ratings = df_IRRatings[df_IRRatings['strRatingAgency'] == 'FITCH'][['strRating', 'numRating']]
    fh_ratings.columns = ['strInstRtgFHStandardized', 'numRatingFH']
    
    # Merge all rating mappings
    df_with_ratings = df_bkgn7.copy()
    df_with_ratings = df_with_ratings.merge(sp_ratings, on='strInstRtgSPStandardized', how='left')
    df_with_ratings = df_with_ratings.merge(md_ratings, on='strInstRtgMDStandardized', how='left')
    df_with_ratings = df_with_ratings.merge(fh_ratings, on='strInstRtgFHStandardized', how='left')
    
    # Fill missing ratings with 0
    df_with_ratings['numRatingSP'] = df_with_ratings['numRatingSP'].fillna(0)
    df_with_ratings['numRatingMD'] = df_with_ratings['numRatingMD'].fillna(0)
    df_with_ratings['numRatingFH'] = df_with_ratings['numRatingFH'].fillna(0)
    
    # Calculate weighted ratings
    df_with_ratings['numWeightSP'] = np.where(df_with_ratings['numRatingSP'] != 0, df_with_ratings['numweight'], 0)
    df_with_ratings['numRatingWeightSP'] = df_with_ratings['numweight'] * df_with_ratings['numRatingSP']
    
    df_with_ratings['numWeightMD'] = np.where(df_with_ratings['numRatingMD'] != 0, df_with_ratings['numweight'], 0)  
    df_with_ratings['numRatingWeightMD'] = df_with_ratings['numweight'] * df_with_ratings['numRatingMD']
    
    df_with_ratings['numWeightFH'] = np.where(df_with_ratings['numRatingFH'] != 0, df_with_ratings['numweight'], 0)
    df_with_ratings['numRatingWeightFH'] = df_with_ratings['numweight'] * df_with_ratings['numRatingFH']
    
    # Filter out instruments with no ratings (equivalent to SQL WHERE clause)
    rating_filter = (
        (df_with_ratings['strInstRtgSPStandardized'].notna()) |
        (df_with_ratings['strInstRtgMDStandardized'].notna()) |
        (df_with_ratings['strInstRtgFHStandardized'].notna())
    )
    df_tblDMIRBKGN8 = df_with_ratings[rating_filter].copy()
    
    return df_tblDMIRBKGN8, df_IRRatings
```

### 2. Rating Interpolation (BKGN_9)
**SQL Section**: Lines 1800-1900 (benchmark average rating calculation and interpolation)  
**Python Implementation**: `compute_bench_indicators_bkgn_9()`

**SQL Logic**:
```sql
-- Calculate benchmark weighted average ratings
SELECT 
    numBenchFBAId,
    strCompositionCd,
    datReportingDay,
    strPeriodTypeFlag,
    strPFCurrencyISOCode,
    numBenchAvgRtgSP = CASE WHEN sum(numWeightSP) <> 0 
                       THEN round(sum(numRatingWeightSP) / sum(numWeightSP),10) 
                       ELSE null END,
    numBenchAvgRtgMD = CASE WHEN sum(numWeightMD) <> 0 
                       THEN round(sum(numRatingWeightMD) / sum(numWeightMD),10) 
                       ELSE null END
FROM #tblDMIRBKGN8
GROUP BY numBenchFBAId, strCompositionCd, datReportingDay, strPeriodTypeFlag, strPFCurrencyISOCode

-- Convert numeric averages back to rating strings using interpolation
SELECT 
    a.*,
    strBenchAvgRtgSP = CASE WHEN (((sp.numRating - sp.numPrevRating)/ 2.0) - (a.numBenchAvgRtgSP - sp.numPrevRating)) > 0.0
                       THEN sp.strPrevRating
                       ELSE sp.strRating END
INTO #tblDMIRBKGN9
FROM benchmark_averages a
LEFT JOIN #IRRatingsBetween sp ON (a.numBenchAvgRtgSP <= sp.numRating 
                                  AND a.numBenchAvgRtgSP > sp.numPrevRating 
                                  AND sp.strRatingAgency = 'SP')
```

**Python Equivalent**:
```python
def compute_bench_indicators_bkgn_9(df_tblDMIRBKGN8, df_IRRatings):
    """
    Stage 9: Calculate benchmark average ratings and convert back to rating strings.
    Equivalent to SQL BKGN_9 processing with rating interpolation logic.
    """
    # Step 1: Calculate weighted average ratings by benchmark
    group_cols = ['numBenchFBAId', 'strCompositionCd', 'datReportingDay', 'strPeriodTypeFlag', 'strPFCurrencyISOCode']
    
    benchmark_ratings = df_tblDMIRBKGN8.groupby(group_cols).agg({
        'numWeightSP': 'sum',
        'numRatingWeightSP': 'sum', 
        'numWeightMD': 'sum',
        'numRatingWeightMD': 'sum',
        'numWeightFH': 'sum', 
        'numRatingWeightFH': 'sum'
    }).reset_index()
    
    # Calculate average numeric ratings
    benchmark_ratings['numBenchAvgRtgSP'] = np.where(
        benchmark_ratings['numWeightSP'] != 0,
        np.round(benchmark_ratings['numRatingWeightSP'] / benchmark_ratings['numWeightSP'], 10),
        None
    )
    benchmark_ratings['numBenchAvgRtgMD'] = np.where(
        benchmark_ratings['numWeightMD'] != 0,
        np.round(benchmark_ratings['numRatingWeightMD'] / benchmark_ratings['numWeightMD'], 10), 
        None
    )
    benchmark_ratings['numBenchAvgRtgFH'] = np.where(
        benchmark_ratings['numWeightFH'] != 0,
        np.round(benchmark_ratings['numRatingWeightFH'] / benchmark_ratings['numWeightFH'], 10),
        None  
    )
    
    # Step 2: Create rating interpolation tables
    df_IRRatingsBetween = create_rating_interpolation_table(df_IRRatings)
    
    # Step 3: Convert numeric ratings back to strings using interpolation
    def interpolate_rating(avg_rating, rating_agency):
        """Interpolate numeric rating to rating string using between-rating logic"""
        if pd.isna(avg_rating):
            return None
            
        agency_ratings = df_IRRatingsBetween[df_IRRatingsBetween['strRatingAgency'] == rating_agency]
        
        # Find the rating bracket where the average falls
        matching_rating = agency_ratings[
            (agency_ratings['numPrevRating'] < avg_rating) & 
            (avg_rating <= agency_ratings['numRating'])
        ]
        
        if len(matching_rating) > 0:
            row = matching_rating.iloc[0]
            # Interpolation logic: closer to previous or current rating?
            midpoint = (row['numRating'] + row['numPrevRating']) / 2.0
            if (avg_rating - row['numPrevRating']) > (midpoint - row['numPrevRating']):
                return row['strPrevRating']
            else:
                return row['strRating']
        
        return None
    
    # Apply rating interpolation
    benchmark_ratings['strBenchAvgRtgSP'] = benchmark_ratings['numBenchAvgRtgSP'].apply(
        lambda x: interpolate_rating(x, 'SP')
    )
    benchmark_ratings['strBenchAvgRtgMD'] = benchmark_ratings['numBenchAvgRtgMD'].apply(
        lambda x: interpolate_rating(x, 'MOODY')
    )
    benchmark_ratings['strBenchAvgRtgFH'] = benchmark_ratings['numBenchAvgRtgFH'].apply(
        lambda x: interpolate_rating(x, 'FITCH')
    )
    
    return benchmark_ratings
```

### 3. ESG Aggregation Processing
**SQL Section**: Lines 2020-2150 (ESG metrics aggregation from instrument to benchmark level)  
**Python Implementation**: `aggregate_esg_indicators()`

**SQL Logic**:
```sql
-- Aggregate ESG metrics from instrument to benchmark level
SELECT
    ddmwi.strPeriodTypeFlag,
    ddmwi.numBenchFBAId,
    ddmwi.datPeriodLastDay,
    sum(isnull(ddmwi.numESGGlbCovWeight,0)) as numESGGlbCovWeight,
    sum(isnull(ddmwi.numESGEnvCovWeight,0)) as numESGEnvCovWeight,
    sum(isnull(ddmwi.numESGEnvScoreCov,0)) as numESGEnvScoreCov,
    sum(isnull(ddmwi.numESGSocialCovWeight,0)) as numESGSocialCovWeight,
    sum(isnull(ddmwi.numESGSocialScoreCov,0)) as numESGSocialScoreCov,
    sum(isnull(ddmwi.numESGGovCovWeight,0)) as numESGGovCovWeight,
    sum(isnull(ddmwi.numESGGovernanceScoreCov,0)) as numESGGovernanceScoreCov,
    sum(isnull(ddmwi.numCO2IntensEVEvalCovWeight,0)) as numCO2IntensEVEvalCovWeight,
    sum(isnull(ddmwi.numCO2IntensEVEvalCov,0)) as numCO2IntensEVEvalCov
INTO #esg_aggregated_data
FROM DMIR.tblDMIRBRSBenchInstrIndicators ddmwi
WHERE ddmwi.strPeriodTypeFlag = @strPeriodTypeFlag
  AND ddmwi.datPeriodLastDay = @datPeriodLastDay
GROUP BY ddmwi.strPeriodTypeFlag, ddmwi.numBenchFBAId, ddmwi.datPeriodLastDay
```

**Python Equivalent**:
```python
def aggregate_esg_indicators(df_instrument_indicators):
    """
    Aggregate ESG metrics from instrument to benchmark level.
    Equivalent to SQL ESG aggregation processing.
    """
    # Define grouping columns
    group_cols = ['strPeriodTypeFlag', 'numBenchFBAId', 'datPeriodLastDay']
    
    # Define ESG columns to aggregate
    esg_agg_cols = {
        'numESGGlbCovWeight': 'sum',
        'numESGEnvCovWeight': 'sum', 
        'numESGEnvScoreCov': 'sum',
        'numESGSocialCovWeight': 'sum',
        'numESGSocialScoreCov': 'sum',
        'numESGGovCovWeight': 'sum',
        'numESGGovernanceScoreCov': 'sum',
        'numESGDecileCovWeight': 'sum',
        'numESGDecileCov': 'sum',
        'numESGGlbPotentialScoreCov': 'sum',
        'numCO2IntensEVEvalCovWeight': 'sum',
        'numCO2IntensEVEvalCov': 'sum',
        'numCO2EmmissionCovWeight': 'sum',
        'numCO2EmmisionsCov': 'sum',
        'numESGKPIGenderDivCovWeight': 'sum',
        'numESGKPIGenderDivValuCov': 'sum',
        'numESGKPIHumanRightsCovWeight': 'sum',
        'numESGKPIHumanRightsValuCov': 'sum',
        'numESGKPIExpControvESGCovWeight': 'sum',
        'numESGKPIExpControvESGCov': 'sum'
    }
    
    # Fill NaN values with 0 before aggregation
    df_filled = df_instrument_indicators[group_cols + list(esg_agg_cols.keys())].fillna(0)
    
    # Aggregate ESG metrics
    df_esg_aggregated = df_filled.groupby(group_cols).agg(esg_agg_cols).reset_index()
    
    # Calculate composite ESG Global Score (E + S + G + 50 adjustment)
    df_esg_aggregated['numESGGlbScoreCov'] = (
        df_esg_aggregated['numESGEnvScoreCov'] + 
        df_esg_aggregated['numESGSocialScoreCov'] + 
        df_esg_aggregated['numESGGovernanceScoreCov'] + 50
    )
    
    return df_esg_aggregated
```

### 4. Final Data Persistence
**SQL Section**: Lines 2300-2489 (delete existing records and insert new benchmark indicators)  
**Python Implementation**: `final_delete_and_insert_indicators()`

**SQL Logic**:
```sql
-- Delete existing benchmark indicators for the processing scope
DELETE DMIR.tblDMIRBRSBenchIndicators
FROM DMIR.tblDMIRBRSBenchIndicators a,
     (SELECT strPeriodTypeFlag, datPeriodLastDay, numBenchFBAId
      FROM DMIR.tblDMIRBenchIndicatorsWrk
      GROUP BY strPeriodTypeFlag, datPeriodLastDay, numBenchFBAId) b
WHERE a.strPeriodTypeFlag = b.strPeriodTypeFlag
  AND a.datPeriodLastDay = b.datPeriodLastDay
  AND a.numBenchFBAId = b.numBenchFBAId

-- Insert new calculated benchmark indicators
INSERT INTO DMIR.tblDMIRBRSBenchIndicators (
    strPeriodTypeFlag, datPeriodLastDay, numBenchFBAId,
    numEffectDurationBench, numBenchAvgYTM, numBenchAvgConvexity,
    strBenchAvgRtgSP, strBenchAvgRtgMD, strBenchAvgRtgFH,
    numESGGlbCovWeight, numESGEnvScoreCov, numCO2IntensEVEvalCov,
    -- ... all benchmark indicator columns
)
SELECT strPeriodTypeFlag, datPeriodLastDay, numBenchFBAId,
       numEffectDurationBench, numBenchAvgYTM, numBenchAvgConvexity,
       strBenchAvgRtgSP, strBenchAvgRtgMD, strBenchAvgRtgFH,
       numESGGlbCovWeight, numESGEnvScoreCov, numCO2IntensEVEvalCov,
       -- ... all corresponding values
FROM DMIR.tblDMIRBenchIndicatorsWrk
```

**Python Equivalent**:
```python
def final_delete_and_insert_indicators(df_scope, df_ratings, df_analytics, df_esg, audit_id):
    """
    Final step: Delete existing records and insert new benchmark indicators.
    Equivalent to SQL delete/insert operations with transaction management.
    """
    session = get_session()
    try:
        # Merge all dataframes to create final benchmark indicators
        df_final = df_analytics.copy()
        df_final = df_final.merge(df_ratings, on=['numBenchFBAId', 'strPeriodTypeFlag', 'datReportingDay'], how='left')
        df_final = df_final.merge(df_esg, on=['numBenchFBAId', 'strPeriodTypeFlag', 'datReportingDay'], how='left')
        
        # Add audit information
        df_final['datModificationDate'] = datetime.now()
        df_final['numAuditId'] = audit_id
        
        # Get unique benchmark/period combinations for deletion
        delete_scope = df_final[['strPeriodTypeFlag', 'datPeriodLastDay', 'numBenchFBAId']].drop_duplicates()
        
        # Delete existing records in chunks
        delete_count = 0
        for chunk in [delete_scope[i:i+100] for i in range(0, len(delete_scope), 100)]:
            delete_conditions = []
            for _, row in chunk.iterrows():
                delete_conditions.append(
                    and_(
                        DMIRBRSBenchIndicators.strPeriodTypeFlag == row['strPeriodTypeFlag'],
                        DMIRBRSBenchIndicators.datPeriodLastDay == row['datPeriodLastDay'],
                        DMIRBRSBenchIndicators.numBenchFBAId == row['numBenchFBAId']
                    )
                )
            
            delete_count += session.query(DMIRBRSBenchIndicators).filter(
                or_(*delete_conditions)
            ).delete(synchronize_session=False)
        
        # Insert new records in chunks
        insert_count = 0
        for chunk in [df_final[i:i+1000] for i in range(0, len(df_final), 1000)]:
            chunk_records = chunk.to_dict('records')
            session.bulk_insert_mappings(DMIRBRSBenchIndicators, chunk_records)
            insert_count += len(chunk_records)
        
        session.commit()
        
        return {
            'deleted_rows': delete_count,
            'inserted_rows': insert_count,
            'final_data': df_final
        }
        
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()
```