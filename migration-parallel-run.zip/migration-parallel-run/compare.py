#!/usr/bin/env python3
"""
Daily parallel‑run validation:
  • Executes every .sql file in ./sql/
  • Renders results into a single Bootstrap‑styled HTML file using Jinja2
"""
import os, datetime as dt
import pandas as pd
from sqlalchemy import create_engine, text
from jinja2 import Environment, FileSystemLoader

TODAY = dt.date.today()

# Runtime parameters (edit as needed)
YESTERDAY_AUD = int((TODAY - dt.timedelta(days=1)).strftime("%Y%m%d")) * 10_000_000_000
FBA_ID_FOR_TEST = 194220
MARKET_DATE = dt.date(2025, 6, 30)
ACCOUNTING_DATE = dt.date(2025, 6, 30)
BENCH_CODE = 199995

# Connection string (put real creds in env var SQL_CONN)
CONN_STR = os.getenv(
    "SQL_CONN",
    "mssql+pyodbc://report_user:***@SERVERNAME/DBNAME?driver=ODBC+Driver+18+for+SQL+Server",
)
engine = create_engine(CONN_STR, fast_executemany=True)


def render_sql(path: str) -> str:
    """Load file and substitute placeholders."""
    with open(path, encoding="utf-8") as f:
        sql = f.read()
    return sql.format(
        yesterday_audit=YESTERDAY_AUD,
        FBA_ID_FOR_TEST=FBA_ID_FOR_TEST,
        market_date=MARKET_DATE,
        accounting_date=ACCOUNTING_DATE,
        bench_code=BENCH_CODE,
    )


def run_queries():
    """Execute every *.sql file in ./sql and return a list of DataFrames.

    - Uses a single connection opened once for the whole loop.
    - Feeds the raw SQL string to pandas read_sql_query (works in SQLAlchemy 1.x).
    """
    dfs = []

    # open one connection for all queries (SA-1 compatible)
    with engine.connect() as conn:
        for name in sorted(os.listdir("sql")):
            if not name.endswith(".sql"):
                continue

            # render placeholders (yesterday_audit, FBA_ID_FOR_TEST, …)
            sql_text = render_sql(os.path.join("sql", name))

            # pandas handles the fetch+DataFrame creation
            df = pd.read_sql_query(sql_text, conn)

            # tag the DataFrame with its source file
            df["__source_sql__"] = name
            dfs.append(df)

    return dfs


def build_html(dfs):
    env = Environment(loader=FileSystemLoader("templates"), autoescape=True)
    tpl = env.get_template("report.html.j2")
    tables_html = []
    for df in dfs:
        styled = df.style.set_table_attributes(
            'class="table table-sm table-striped"'
        ).hide(axis="index")
        tables_html.append(styled.to_html())
    return tpl.render(date=TODAY, tables=tables_html)


def main():
    dfs = run_queries()
    html = build_html(dfs)
    out_path = f"parallel_run_report_{TODAY:%Y%m%d}.html"
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"✅ Report written to {out_path}")


if __name__ == "__main__":
    main()
