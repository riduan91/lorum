WITH a AS (
    SELECT *
    FROM DMIR.tblDMIRBenchScopeAG
    WHERE numAuditId >= {yesterday_audit}
),
b AS (
    SELECT *
    FROM dbo.tblDMIRBenchScopeAG
    WHERE numAuditId >= {yesterday_audit}
)
SELECT ISNULL(a.strPeriodTypeFlag, b.strPeriodTypeFlag) AS strPeriodTypeFlag,
       ISNULL(a.numBenchMarkId, b.numBenchMarkId) AS numBenchMarkId,
       ISNULL(a.datPeriodLastDay, b.datPeriodLastDay) AS datPeriodLastDay,
       a.numAuditId AS numAuditId_legacy,
       b.numAuditId AS numAuditId_python,
       'tblDMIRBenchScopeAG' AS [table]
FROM a
FULL OUTER JOIN b ON a.strPeriodTypeFlag = b.strPeriodTypeFlag
                 AND a.numBenchMarkId = b.numBenchMarkId
                 AND a.datPeriodLastDay = b.datPeriodLastDay
ORDER BY 1,2,3;
