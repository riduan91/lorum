WITH sum_a AS (
    SELECT BKGNCode, Accountingdate, numAuditId, COUNT(*) AS count
    FROM DMIR.tblDMIRAPIBenchHolding
    WHERE numAuditId >= {yesterday_audit}
    GROUP BY BKGNCode, Accountingdate, numAuditId
),
sum_b AS (
    SELECT BKGNCode, Accountingdate, numAuditId, COUNT(*) AS count
    FROM dbo.tblDMIRAPIBenchHolding
    WHERE numAuditId >= {yesterday_audit}
    GROUP BY BKGNCode, Accountingdate, numAuditId
)
SELECT ISNULL(sum_a.BKGNCode, sum_b.BKGNCode) AS BKGNCode,
       ISNULL(sum_a.Accountingdate, sum_b.Accountingdate) AS Accountingdate,
       sum_a.count AS count_legacy,
       sum_b.count AS count_python,
       sum_a.numAuditId AS numAuditId_legacy,
       sum_b.numAuditId AS numAuditId_python,
       'tblDMIRAPIBenchHolding' AS [table]
FROM sum_a
FULL OUTER JOIN sum_b
  ON sum_a.Accountingdate = sum_b.Accountingdate
 AND sum_a.BKGNCode      = sum_b.BKGNCode
ORDER BY 1,2;
