WITH a AS (
    SELECT *
    FROM DMIR.tblDMIRBRSBenchmarkConstituent
    WHERE numAuditId >= {yesterday_audit}
),
b AS (
    SELECT *
    FROM dbo.tblDMIRBRSBenchmarkConstituent
    WHERE numAuditId >= {yesterday_audit}
),
sum_a AS (
    SELECT numAuditId, numBenchFBAId, datMarketDate, COUNT(*) AS count
    FROM a
    GROUP BY numAuditId, numBenchFBAId, datMarketDate
),
sum_b AS (
    SELECT numAuditId, numBenchFBAId, datMarketDate, COUNT(*) AS count
    FROM b
    GROUP BY numAuditId, numBenchFBAId, datMarketDate
)
SELECT ISNULL(sum_a.numBenchFBAId, sum_b.numBenchFBAId) AS numBenchFBAId,
       ISNULL(sum_a.datMarketDate, sum_b.datMarketDate) AS datMarketDate,
       sum_a.numAuditId AS numAuditId_legacy,
       sum_b.numAuditId AS numAuditId_python,
       sum_a.count AS count_legacy,
       sum_b.count AS count_python,
       'tblDMIRBRSBenchmarkConstituent' AS [table]
FROM sum_a
FULL OUTER JOIN sum_b
  ON sum_a.numBenchFBAId = sum_b.numBenchFBAId
 AND sum_a.datMarketDate = sum_b.datMarketDate
ORDER BY 1,2;
