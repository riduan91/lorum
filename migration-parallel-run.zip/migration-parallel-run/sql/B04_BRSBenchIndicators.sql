WITH a AS (
    SELECT *
    FROM DMIR.tblDMIRBRSBenchIndicators
    WHERE numAuditId >= {yesterday_audit}
),
b AS (
    SELECT *
    FROM dbo.tblDMIRBRSBenchIndicators
    WHERE numAuditId >= {yesterday_audit}
),
sum_a AS (
    SELECT strPeriodTypeFlag, numBenchFBAId, datPeriodLastDay, numAuditId, COUNT(*) AS count
    FROM a
    GROUP BY strPeriodTypeFlag, numBenchFBAId, datPeriodLastDay, numAuditId
),
sum_b AS (
    SELECT strPeriodTypeFlag, numBenchFBAId, datPeriodLastDay, numAuditId, COUNT(*) AS count
    FROM b
    GROUP BY strPeriodTypeFlag, numBenchFBAId, datPeriodLastDay, numAuditId
)
SELECT ISNULL(sum_a.strPeriodTypeFlag, sum_b.strPeriodTypeFlag) AS strPeriodTypeFlag,
       ISNULL(sum_a.numBenchFBAId, sum_b.numBenchFBAId) AS numBenchFBAId,
       ISNULL(sum_a.datPeriodLastDay, sum_b.datPeriodLastDay) AS datPeriodLastDay,
       sum_a.numAuditId AS numAuditId_legacy,
       sum_b.numAuditId AS numAuditId_python,
       sum_a.count AS count_legacy,
       sum_b.count AS count_python,
       'tblDMIRBRSBenchIndicators' AS [table]
FROM sum_a
FULL OUTER JOIN sum_b
  ON sum_a.strPeriodTypeFlag = sum_b.strPeriodTypeFlag
 AND sum_a.numBenchFBAId     = sum_b.numBenchFBAId
 AND sum_a.datPeriodLastDay  = sum_b.datPeriodLastDay
ORDER BY 1,2,3;
